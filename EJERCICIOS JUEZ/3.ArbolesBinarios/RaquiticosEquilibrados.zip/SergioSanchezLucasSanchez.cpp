/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 *              Facultad de Inform�tica
 *         Universidad Complutense de Madrid
 * ---------------------------------------------------
 */

 /*
  * MUY IMPORTANTE: Para realizar este ejercicio solo pod�is
  * modificar el c�digo contenido entre las etiquetas <answer>
  * y </answer>. Toda modificaci�n fuera de esas etiquetas est�
  * prohibida, pues no se tendr� en cuenta para la correcci�n.
  *
  * Tampoco esta permitido modificar las l�neas que contienen
  * las etiquetas <answer> y </answer>, obviamente :-)
  */


  //@ <answer>
  /*
    Indica el nombre y apellidos de los componentes del grupo
    ---------------------------------------------------------
    Componente 1:Sergio S�nchez Carrasco
    Componente 2: Lucas S�nchez Mart�n.
  */
  //@ </answer>



#include <iostream>
#include <fstream>
#include <cassert>
#include <memory>
#include <utility>  // Para la clase pair
#include <tuple>    // Para la clase tuple

using namespace std;

/*
  Implementaci�n de �rboles binarios vista en clase
*/

template <class T> class BinTree {
public:
    BinTree() : root_node(nullptr) {}

    BinTree(const T& elem)
        : root_node(std::make_shared<TreeNode>(nullptr, elem, nullptr)) {}

    BinTree(const BinTree& left, const T& elem, const BinTree& right)
        : root_node(std::make_shared<TreeNode>(left.root_node, elem,
            right.root_node)) {}

    bool empty() const { return root_node == nullptr; }

    const T& root() const {
        assert(root_node != nullptr);
        return root_node->elem;
    }

    BinTree left() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->left;
        return result;
    }

    BinTree right() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->right;
        return result;
    }

    void display(std::ostream& out) const { display_node(root_node, out); }

private:
    // Las definiciones de TreeNode y NodePointer dependen recursivamente
    // la una de la otra. Por eso declaro 'struct TreeNode;' antes de NodePointer
    // para que el compilador sepa, cuando analice la definici�n de NodePointer,
    // que TreeNode va a ser definida m�s adelante.

    struct TreeNode;
    using NodePointer = std::shared_ptr<TreeNode>;

    struct TreeNode {
        TreeNode(const NodePointer& left, const T& elem, const NodePointer& right)
            : elem(elem), left(left), right(right) {}

        T elem;
        NodePointer left, right;
    };

    NodePointer root_node;

    static void display_node(const NodePointer& root, std::ostream& out) {
        if (root == nullptr) {
            out << ".";
        }
        else {
            out << "(";
            display_node(root->left, out);
            out << " " << root->elem << " ";
            display_node(root->right, out);
            out << ")";
        }
    }
};

template <typename T>
std::ostream& operator<<(std::ostream& out, const BinTree<T>& tree) {
    tree.display(out);
    return out;
}

template <typename T> BinTree<T> read_tree(std::istream& in) {
    char c;
    in >> c;
    if (c == '.') {
        return BinTree<T>();
    }
    else {
        assert(c == '(');
        BinTree<T> left = read_tree<T>(in);
        T elem;
        in >> elem;
        BinTree<T> right = read_tree<T>(in);
        in >> c;
        assert(c == ')');
        BinTree<T> result(left, elem, right);
        return result;
    }
}




//@ <answer>
// ----------------------------------------------
// Modificar a partir de aqu�
// ----------------------------------------------

// Define las funciones auxiliares que sean necesarias. Para cada una de
// ellas, indica y justifica su coste.

/*
Inicialmente hab�a pensado en que devolviera un par que dijera si es equilibrado y su altura.
Pero voy a usar mejor una tupla que diga si es equilibrado, si es raquitico y su altura
*/

template <typename T>/*el primer parametro es para saber si es equilibrado,el segundo parametro es para saber si es raquitico ,el tercero es para la altura*/
tuple<bool,bool, int>raquiticoEquilibradoNada(const BinTree<T>& tree) {

    if (tree.empty())
    {
        return { true,true ,0};
    }   
    else
    {

        auto[esEquilibrado_izquierda, esRaquitico_izquierda,altura_izquierda] = raquiticoEquilibradoNada(tree.left());
        auto[esEquilibrado_derecha,esRaquitico_derecha ,altura_derecha] = raquiticoEquilibradoNada(tree.right());
        bool esRaquitico;

        int altura = 1 + max(altura_izquierda, altura_derecha);
        bool esEquilibrado = esEquilibrado_izquierda && esEquilibrado_derecha && abs(altura_izquierda - altura_derecha) <= 1;

        if (altura >1)//Solo tiene sentido esto si la altura es >1.
        {
             esRaquitico = (esRaquitico_izquierda && esRaquitico_derecha) && abs(altura_izquierda - altura_derecha) == 1;
        }
         

        return { esEquilibrado,esRaquitico ,altura };
         
    }
}

/*
EXPLICACI�N DEL COSTE Y DE LA RECURRENCIA:
RECORDATORIO:
El primer par�metro de la funci�n es para saber si es equilibrado,el segundo para saber si es raqu�tico y el tercero es para la altura.
He estado barajando la idea de a�adir un cuarto argumento a la tupla para incluir el n�mero de nodos de cada sub-�rbol que exploramos,
pero no es necesario.
Algo muy importante tambi�n a tener en cuenta es que solo tenemos una funci�n recursiva, es decir, no he creado una funci�n distinta para
la altura, otra distinta para saber si es equilibrado y otra distinta para saber si es raquitico el �rbol. Todo lo he puesto en la misma 
funci�n para evitar que hubiera penalizaciones en el coste.
Para definir el la recurrencia y el coste del algoritmo primero resalto que lo voy a definir sobre un n�mero "n" siendo este n el n�mero
de nodos del �rbol. La recurrencia es de la siguiente forma:

          { k0                  si n =0; Constante ya que solo devuelve true true y 0.
    T(n) =
          {T(ni) + T(nd) +k1    si n>0;

    Por tanto, sabiendo la forma de la recurrencia deduzco que el coste de mi algoritmo es T(n)=n;

*/

// Implementa aqu� la funci�n para tratar UN caso de prueba.
void tratar_caso() {
    BinTree<char> t = read_tree<char>(cin);

    auto[esEquilibrado, esRaquitico, altura] = raquiticoEquilibradoNada(t);

    if (esEquilibrado && !esRaquitico)
    {
        cout << "EQUILIBRADO\n";
    }
    else if (esEquilibrado && esRaquitico)
    {
        cout << "RAQUITICO\n";
    }
    else
    {
        cout << "NADA\n";
    }
   

}

// ----------------------------------------------
// No modificar a partir de la l�nea
// ----------------------------------------------
//@ </answer>


int main() {
    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
    // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
    // �til para no tener que teclear los casos de prueba por teclado cada vez
    // que ejecutas el programa.
    //
    // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
    // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // La entrada comienza con el n�mero de casos de prueba.
    int num_casos;
    cin >> num_casos;

    // Llamamos a `tratar_caso` tantas veces como el n�mero anterior.
    for (int i = 0; i < num_casos; i++) {
        tratar_caso();
    }

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
