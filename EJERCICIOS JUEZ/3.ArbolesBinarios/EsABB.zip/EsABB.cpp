// �Es un �rbol binario de b�squeda?
// ---------------------------------
// Estructuras de datos


#include <iostream>
#include <cassert>
#include <memory>
#include <utility>
#include <vector>
#include <queue>
#include <stack>
#include <fstream>
#include <algorithm>

// TAD de �rboles binarios de b�squeda
template <class T> class BinTree {

private:
    struct TreeNode;
    using NodePointer = std::shared_ptr<TreeNode>;

public:
    BinTree() : root_node(nullptr) {}
    BinTree(const T& elem)
        : root_node(std::make_shared<TreeNode>(nullptr, elem, nullptr)) {}

    BinTree(const BinTree& left, const T& elem, const BinTree& right)
        : root_node(std::make_shared<TreeNode>(left.root_node, elem,
            right.root_node)) {}

    bool empty() const { return root_node == nullptr; }

    const T& root() const {
        assert(root_node != nullptr);
        return root_node->elem;
    }

    BinTree left() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->left;
        return result;
    }

    BinTree right() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->right;
        return result;
    }

    void display(std::ostream& out) const { display_node(root_node, out); }

    template <typename U> void preorder(U func) const {
        preorder(root_node, func);
    }

    template <typename U> void inorder(U func) const { inorder(root_node, func); }

    template <typename U> void postorder(U func) const {
        postorder(root_node, func);
    }

    template <typename U> void levelorder(U func) const;

private:
    struct TreeNode {
        TreeNode(const NodePointer& left, const T& elem, const NodePointer& right)
            : elem(elem), left(left), right(right) {}

        T elem;
        NodePointer left, right;
    };

    NodePointer root_node;

    static void display_node(const NodePointer& root, std::ostream& out) {
        if (root == nullptr) {
            out << ".";
        }
        else {
            out << "(";
            display_node(root->left, out);
            out << " " << root->elem << " ";
            display_node(root->right, out);
            out << ")";
        }
    }

    template <typename U> static void preorder(const NodePointer& node, U func);

    template <typename U> static void inorder(const NodePointer& node, U func);

    template <typename U> static void postorder(const NodePointer& node, U func);
};

template <typename T>
template <typename U>
void BinTree<T>::preorder(const NodePointer& node, U func) {
    if (node != nullptr) {
        func(node->elem);
        preorder(node->left, func);
        preorder(node->right, func);
    }
}

template <typename T>
template <typename U>
void BinTree<T>::inorder(const NodePointer& node, U func) {
    if (node != nullptr) {
        inorder(node->left, func);
        func(node->elem);
        inorder(node->right, func);
    }
}

template <typename T>
template <typename U>
void BinTree<T>::postorder(const NodePointer& node, U func) {
    if (node != nullptr) {
        postorder(node->left, func);
        postorder(node->right, func);
        func(node->elem);
    }
}

template <typename T>
template <typename U>
void BinTree<T>::levelorder(U func) const {
    std::queue<NodePointer> pending;
    if (root_node != nullptr) {
        pending.push(root_node);
    }
    while (!pending.empty()) {
        NodePointer current = pending.front();
        pending.pop();
        func(current->elem);
        if (current->left != nullptr) {
            pending.push(current->left);
        }
        if (current->right != nullptr) {
            pending.push(current->right);
        }
    }
}

template <typename T>
std::ostream& operator<<(std::ostream& out, const BinTree<T>& tree) {
    tree.display(out);
    return out;
}

template <typename T> BinTree<T> read_tree(std::istream& in) {
    char c;
    in >> c;
    if (c == '.') {
        return BinTree<T>();
    }
    else {
        assert(c == '(');
        BinTree<T> left = read_tree<T>(in);
        T elem;
        in >> elem;
        BinTree<T> right = read_tree<T>(in);
        in >> c;
        assert(c == ')');
        BinTree<T> result(left, elem, right);
        return result;
    }
}

using namespace std;


// Define las funciones auxiliares que veas necesarias
/*
PARAMETROS:

Parametro 1: booleano que indica que es de busqueda o no.
Parametro 2: valor menor.
Parametro 3: valor mayor.
*/
template <typename T>
tuple<bool,T,T> es_arbol_busqueda(const BinTree<T>& arbol) {
    // Implementar
    if (arbol.empty())
    {
        return {true, T(),T()};
    }
    else
    {
        auto [busqueda_izquierda, menor_izquierda, mayor_izquierda] = es_arbol_busqueda(arbol.left());
        auto [busqueda_derecha, menor_derecha, mayor_derecha] = es_arbol_busqueda(arbol.right());
        
        T menor = arbol.left().empty() ? arbol.root() : menor_izquierda;
        T mayor = arbol.right().empty() ? arbol.root() : mayor_derecha;

        bool esABBs = busqueda_derecha && busqueda_izquierda && (arbol.left().empty() || mayor_izquierda < arbol.root())&&(arbol.right().empty()||menor_derecha > arbol.root());
       
        return {esABBs, menor,mayor};
    }



}



/*
COSTE Y RECURRENCIA DE MI �RBOL BINARIO

El coste del �rbol binario de b�squeda lo voy a definir sobre el n�mero de nodos
del propio �rbol, el cual es "n". La forma de la recurrencia es la siguiente:

        {k0                 si n =0;
    T(n)
        {T(ni) + T(nd) +k1  si n >0;


    Por tanto, en consecuencia de la recurrencia el coste de nuestro �rbol binario 
    es lineal respecto al n�mero de nodos n, luego O(n). Destaco la importancia de 
    obtener todos los resultados dentro de la misma funci�n para que, en este caso
    , no hacer 3 funciones disitintas. De hacer eso el coste aumentar�a y ser�a del
    orden de O(n^3). Por tanto ganamos en eficiencia.
*/

bool tratar_caso() {
    // Introduce aqu� el c�digo para tratar un caso de prueba. Devuelve true si
    // se ha encontrado un caso de prueba, o false si se ha encontrado con el
    // fin de fichero.

    char tipo_arbol;

    cin >> tipo_arbol;

    if (cin.eof())
    {
        return false;
    }

    if (tipo_arbol == 'N')
    {
        BinTree<int> t = read_tree<int>(cin);
        auto[esABB,menor,mayor]=es_arbol_busqueda(t);
        if (esABB)
        {
            cout << "SI\n";
        }
        else
        {
            cout << "NO\n";
        }
    }
    else if (tipo_arbol == 'P')
    {
        BinTree<string> t = read_tree<string>(cin);
        auto [esABB, menor, mayor] = es_arbol_busqueda(t);
        if (esABB)
        {
            cout << "SI\n";
        }
        else
        {
            cout << "NO\n";
        }
    }
    

    // Tendr�s que utilizar read_tree<string> o read_tree<int> en funci�n de si la primera l�nea
    // leida es N o P.

    return true;
}

int main() {
#ifndef DOMJUDGE
    ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
   

    // Ejecutamos tratar_caso() tantas veces como diga el n�mero le�do
    tratar_caso(); while (tratar_caso()){}
    


#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
} // main