// Entramar dos listas doblemente enlazadas
// ----------------------------------------
// Estructuras de datos

#include <iostream>
#include <fstream>
#include <iostream>
#include <cassert>

using namespace std;

class ListLinkedDouble {
private:
    struct Node {
        int value;
        Node* next;
        Node* prev;
    };

public:
    ListLinkedDouble() : num_elems(0) {
        head = new Node;
        head->next = head;
        head->prev = head;
    }

    ListLinkedDouble(const ListLinkedDouble& other) : ListLinkedDouble() {
        copy_nodes_from(other);
        num_elems = other.num_elems;
    }

    ~ListLinkedDouble() { delete_nodes(); }

    void push_front(const int& elem) {
        Node* new_node = new Node{ elem, head->next, head };
        head->next->prev = new_node;
        head->next = new_node;
        num_elems++;
    }

    void push_back(const int& elem) {
        Node* new_node = new Node{ elem, head, head->prev };
        head->prev->next = new_node;
        head->prev = new_node;
        num_elems++;
    }

    void pop_front() {
        assert(num_elems > 0);
        Node* target = head->next;
        head->next = target->next;
        target->next->prev = head;
        delete target;
        num_elems--;
    }

    void pop_back() {
        assert(num_elems > 0);
        Node* target = head->prev;
        target->prev->next = head;
        head->prev = target->prev;
        delete target;
        num_elems--;
    }

    int size() const { return num_elems; }

    bool empty() const { return num_elems == 0; };

    const int& front() const {
        assert(num_elems > 0);
        return head->next->value;
    }

    int& front() {
        assert(num_elems > 0);
        return head->next->value;
    }

    const int& back() const {
        assert(num_elems > 0);
        return head->prev->value;
    }

    int& back() {
        assert(num_elems > 0);
        return head->prev->value;
    }

    const int& operator[](int index) const {
        assert(0 <= index && index < num_elems);
        Node* result_node = nth_node(index);
        return result_node->value;
    }

    int& operator[](int index) {
        assert(0 <= index && index < num_elems);
        Node* result_node = nth_node(index);
        return result_node->value;
    }

    ListLinkedDouble& operator=(const ListLinkedDouble& other) {
        if (this != &other) {
            delete_nodes();
            head = new Node;
            head->next = head->prev = head;
            copy_nodes_from(other);
            num_elems = other.num_elems;
        }
        return *this;
    }

    void display(std::ostream& out) const;

    void display() const { display(std::cout); }

    // El m�todo se implementa m�s abajo, fuera de la definici�n de la clase.
    void zip(ListLinkedDouble& other);

    void detach(Node* other);

    void attach(Node* other, Node* position);

private:
    // Declara aqu� los m�todos auxiliares privados que necesites,

    Node* head;
    int num_elems;

    Node* nth_node(int n) const;
    void delete_nodes();
    void copy_nodes_from(const ListLinkedDouble& other);
};

ListLinkedDouble::Node* ListLinkedDouble::nth_node(int n) const {
    int current_index = 0;
    Node* current = head->next;

    while (current_index < n && current != head) {
        current_index++;
        current = current->next;
    }

    return current;
}

void ListLinkedDouble::delete_nodes() {
    Node* current = head->next;
    while (current != head) {
        Node* target = current;
        current = current->next;
        delete target;
    }

    delete head;
}

void ListLinkedDouble::copy_nodes_from(const ListLinkedDouble& other) {
    Node* current_other = other.head->next;
    Node* last = head;

    while (current_other != other.head) {
        Node* new_node = new Node{ current_other->value, head, last };
        last->next = new_node;
        last = new_node;
        current_other = current_other->next;
    }
    head->prev = last;
}

void ListLinkedDouble::display(std::ostream& out) const {
    out << "[";
    if (head->next != head) {
        out << head->next->value;
        Node* current = head->next->next;
        while (current != head) {
            out << ", " << current->value;
            current = current->next;
        }
    }
    out << "]";
}

std::ostream& operator<<(std::ostream& out, const ListLinkedDouble& l) {
    l.display(out);
    return out;
}

// ===========================================================
// Escribe tu soluci�n por debajo de esta l�nea
// ===========================================================


void ListLinkedDouble::detach(Node* n) {

    n->next->prev = n->prev;
    n->prev->next = n->next;


    //Se apunta a si mismo.
    n->next = n;
    n->prev = n;


}

void ListLinkedDouble::attach(Node* n, Node* position) {

    n->next = position->next;
    n->prev = position;
    position->next->prev = n;
    position->next = n;
}


// Implementa el m�todo pedido aqu�. No te olvides del coste.
void ListLinkedDouble::zip(ListLinkedDouble& other) {//O(max(this.size(),other.size()))

    if (other.empty()) {
        return; // Si la lista "other" est� vac�a, no hay nada que hacer
    }

    Node* curr_this = this->head->next;
    Node* curr_other = other.head->next;

    // Si "this" est� vac�a y "other" no lo est�
    if (this->empty()) {
        while (curr_other != other.head) { // O(other.size()) lineal en el n�mero de nodos de la lista other
            Node* next = curr_other->next;
            other.detach(curr_other);
            other.num_elems--;
            this->attach(curr_other, curr_this);
            this->num_elems++;
            curr_this = curr_this->next;
            curr_other = next;
        }
        return;
    }

    // Si "this" no est� vac�a y "other" no est� vac�a
    while (curr_other != other.head && curr_this != this->head) {//O(max(other.size(),this.size()))
        Node* next_other = curr_other->next;
        Node* next_this = curr_this->next;
        other.detach(curr_other);
        other.num_elems--;
        this->attach(curr_other, curr_this);
        this->num_elems++;
        curr_this = next_this;
        curr_other = next_other;
    }

    // Si a�n quedan elementos en "other" despu�s de llegar al final de "this"
    if (curr_other != other.head) {
        curr_this = curr_this->prev; // Decrementa para apuntar al �ltimo nodo correcto
        while (curr_other != other.head) {//Lineal en el n�mero de elementos restantes en other
            Node* next = curr_other->next;
            other.detach(curr_other);
            other.num_elems--;
            this->attach(curr_other, curr_this);
            this->num_elems++;
            curr_this = curr_this->next;
            curr_other = next;
        }
    }



}


void tratar_caso() {


    ListLinkedDouble xs, zs;
   
    int n, m;//Numero de nums de cada lista 

    cin >> n;


    for (int i = 0; i < n; i++)
    {
        int num;
        cin >> num;

        xs.push_back(num);
    }


    cin >> m;


    for (int i = 0; i < m; i++)
    {
        int num;
        cin >> num;

        zs.push_back(num);
    }       

    xs.zip(zs);

    xs.display(cout);

    cout << endl;
}

int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    int numCasos;

    cin >> numCasos;

    for (int i = 0; i < numCasos; i++)
    {
        tratar_caso();
    }

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    // Descomentar si se trabaja en Windows
    // system("PAUSE");
#endif
    return 0;
}
