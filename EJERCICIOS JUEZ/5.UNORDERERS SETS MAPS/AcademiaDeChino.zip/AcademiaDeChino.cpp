// Academia de Chino
// -----------------
// Estructuras de datos

// A�ade los #include que creas necesarios

#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <unordered_map>
#include <unordered_set>
#include <set>

using namespace std;


class AcademiaChino {
public:

    AcademiaChino() { 
        
        for (int i = 1; i < 7; i++)
        {
            this->grupos_matriculados[i];//O(1)
        }
    
    }

    void nuevo_estudiante(const std::string& dni, int grupo) {//O(1)

        if (this->matriculados_en_la_academia.count(dni))
        {
            throw domain_error("Estudiante existente");
        }
        if (!this->grupos_matriculados.count(grupo))
        {
            throw domain_error("Grupo incorrecto");
        }

        auto it= this->grupos_matriculados[grupo].insert(this->grupos_matriculados[grupo].end(),dni);//O(1)
        this->matriculados_en_la_academia[dni] = { grupo,it };//O(1)
    }

    int grupo_estudiante(const std::string& dni) const {

        if (!this->matriculados_en_la_academia.count(dni))
        {
            throw domain_error("Estudiante no existente");
        }
        if (this->estudiantes_graduados.count(dni))
        {
            throw domain_error("Estudiante ya graduado");
        }

        return this->matriculados_en_la_academia.at(dni).first;//O(1)
    }


    void promocionar(const std::string& dni) {//O(Log(N)) siendo N el n�mero de estudiantes.
        if (!this->matriculados_en_la_academia.count(dni))
        {
            throw domain_error("Estudiante no existente");
        }
        if (this->estudiantes_graduados.count(dni))
        {
            throw domain_error("Estudiante ya graduado");
        }
        if (this->matriculados_en_la_academia.at(dni).first == 6)//O(1)
        {       
            this->grupos_matriculados[this->matriculados_en_la_academia[dni].first].erase(this->matriculados_en_la_academia[dni].second);
            this->estudiantes_graduados.insert(dni);//Olog(N), siendo N el n�mero de estudiantes.
        }
        else
        {
            int grupoActual = this->matriculados_en_la_academia[dni].first;
            this->grupos_matriculados[grupoActual].erase(matriculados_en_la_academia[dni].second);//O(1)
            grupoActual += 1;
            auto it = this->grupos_matriculados[grupoActual].insert(this->grupos_matriculados[grupoActual].end(), dni);//O(1)
            this->matriculados_en_la_academia[dni] = { grupoActual,it };

        }    
    }

    list<std::string> graduados() const {//O(N) siendo N el n�mero de graduados

        list<string> graduados_alfabeticamente;

        for (auto g: this->estudiantes_graduados)//Lineal en el n�mero de graduados
        {
            graduados_alfabeticamente.push_back(g);//O(1)
        }

        return graduados_alfabeticamente;
    }

    std::string novato(int grupo) const {//O(1)

        if (!this->grupos_matriculados.count(grupo))
        {
            throw domain_error("Grupo incorrecto");
        }
        if (this->grupos_matriculados.at(grupo).empty())
        {
            throw domain_error("Grupo vacio");
        }

        return grupos_matriculados.at(grupo).back();
    }


private:

    unordered_map<string, pair<int,list<string>::iterator>>matriculados_en_la_academia;
    unordered_map<int, list<string>> grupos_matriculados;
    set<string>estudiantes_graduados;

};



bool tratar_caso() {
    AcademiaChino ac;
    string comando;
    cin >> comando;
    if (cin.eof()) return false;

    while (comando != "FIN") {
        try {
            if (comando == "nuevo_estudiante") {
                string dni;
                int grupo;
                cin >> dni >> grupo;
                ac.nuevo_estudiante(dni, grupo);
            }
            else if (comando == "grupo_estudiante") {
                string dni;
                cin >> dni;
                int grupo = ac.grupo_estudiante(dni);
                cout << dni << " esta en el grupo " << grupo << "\n";
            }
            else if (comando == "promocionar") {
                string dni;
                cin >> dni;
                ac.promocionar(dni);
            }
            else if (comando == "graduados") {
                list<string> graduados = ac.graduados();
                cout << "Lista de graduados:";
                for (const string& s : graduados) {
                    cout << " " << s;
                }
                cout << "\n";
            }
            else if (comando == "novato") {
                int grupo;
                cin >> grupo;
                string novato = ac.novato(grupo);
                cout << "Novato de " << grupo << ": " << novato << "\n";
            }
        }
        catch (std::domain_error& e) {
            cout << "ERROR: " << e.what() << "\n";
        }

        cin >> comando;
    }
    cout << "---\n";

    return true;
}

int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (tratar_caso()) {}

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    // Descomentar si se trabaja en Windows
    // system("PAUSE");
#endif
    return 0;
}
