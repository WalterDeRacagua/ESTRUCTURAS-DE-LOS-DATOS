// Colas en el supermercado
// ------------------------
// Estructuras de datos

// A�ade los #include que creas necesarios

#include <iostream>
#include <fstream>
#include <list>
#include <vector>
#include <unordered_map>
#include <list>

using namespace std;

class Supermercado {
public:
    Supermercado(int num_colas) {//Lineal en el numero de colas que haya. O(num_colas)

        for (int i = 0; i < num_colas; i++)//Num colas veces
        {
            this->cajas[i];//O(1)
        }

    }

    void nuevo_cliente(const string& dni, int num_cola) {//O(1)

        if (this->clientes.count(dni))
        {
            throw domain_error("Cliente duplicado");
        }
        if (!this->cajas.count(num_cola))
        {
            throw domain_error("Cola inexistente");
        }

        auto& cola = this->cajas[num_cola];//O(1)
        auto it = cola.insert(cola.end(), dni);//Inserta al final de la cola al cliente y me quedo su posicion
        this->clientes[dni] = {num_cola, it};//O(1)
    }

    void cambiar_cola(const string& dni, int num_cola) {//O(1)

        if (!this->cajas.count(num_cola))//O(1)
        {
            throw domain_error("Cola inexistente");
        }

        if (!this->clientes.count(dni))//O(1)
        {
            throw domain_error("Cliente inexistente");
        }

        auto cliente= this->clientes[dni];//O(1)
        int cola_actual = cliente.first;//O(1)

        if (cola_actual== num_cola)
        {
            return;
        }

        auto& nueva_cola = this->cajas[num_cola];//O(1)
        auto it = nueva_cola.insert(nueva_cola.end(), dni);//O(1)
        this->cajas[cola_actual].erase(cliente.second);//O(1)
        this->clientes[dni] = { num_cola,it };//O(1)

    }

    int consultar_cliente(const string& dni) const {//O(1)

        if (!this->clientes.count(dni))
        {
            throw domain_error("Cliente inexistente");
        }


        return this->clientes.at(dni).first;//O(1)
    }

    int cuantos_en_cola(int num_cola) const {//O(1)
        if (!this->cajas.count(num_cola))
        {
            throw domain_error("Cola inexistente");
        }

        return this->cajas.at(num_cola).size();//O(1)
    }

    vector<string> clientes_en_cola(int num_cola) const {//Lineal en el n�mero de elementos de la lista de la cola correspondiente. O(num_cola.size()).
        if (!this->cajas.count(num_cola)) {
            throw domain_error("Cola inexistente");
        }

        const auto& cola = this->cajas.at(num_cola);//O(1)
        vector<string> clientela;

        for (auto it = cola.rbegin(); it != cola.rend(); ++it) {//Numero de elementos de la lista de la cola.
            clientela.push_back(*it);//O(1)
        }

        return clientela;
    }

private:
    
    unordered_map<string, pair<int,list<string>::iterator>> clientes;
    unordered_map<int, list<string>> cajas;

};


bool tratar_caso() {
    int num_colas;
    cin >> num_colas;


    if (cin.eof()) return false;

    Supermercado sup(num_colas);

    string comando;
    cin >> comando;
    while (comando != "FIN") {
        try {
            if (comando == "nuevo_cliente") {
                string dni; cin >> dni;
                int num_cola; cin >> num_cola;
                sup.nuevo_cliente(dni, num_cola);
            }
            else if (comando == "cambiar_cola") {
                string dni; cin >> dni;
                int num_cola; cin >> num_cola;
                sup.cambiar_cola(dni, num_cola);
            }
            else if (comando == "consultar_cliente") {
                string dni; cin >> dni;
                int p = sup.consultar_cliente(dni);
                cout << "El cliente " << dni << " esta en la cola " << p << "\n";
            }
            else if (comando == "cuantos_en_cola") {
                int num_cola; cin >> num_cola;
                int result = sup.cuantos_en_cola(num_cola);
                cout << "En la cola " << num_cola << " hay " << result << " clientes\n";
            }
            else if (comando == "clientes_en_cola") {
                int num_cola; cin >> num_cola;
                vector<string> lista = sup.clientes_en_cola(num_cola);
                cout << "En la cola " << num_cola << " estan:";
                for (const string& s : lista) {
                    cout << " " << s;
                }
                cout << "\n";
            }
        }
        catch (exception& e) {
            cout << "ERROR: " << e.what() << "\n";
        }
        cin >> comando;
    }

    cout << "---\n";
    return true;
}




int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (tratar_caso()) {}

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    // Descomentar si se trabaja en Windows
    // system("PAUSE");
#endif
    return 0;
}