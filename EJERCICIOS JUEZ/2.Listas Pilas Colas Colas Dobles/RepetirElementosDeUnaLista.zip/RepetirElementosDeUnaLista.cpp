// Repetir elementos de una lista
// ------------------------------
// Estructuras de datos

#include <iostream>
#include <string>
#include <cassert>
#include <fstream>

using namespace std;

// Implementaci�n del TAD lista utilizando listas enlazadas simples.

class ListLinkedSingle {
private:
    struct Node {
        int value;
        Node* next;
    };

public:
    ListLinkedSingle() : head(nullptr) { }
    ~ListLinkedSingle() {
        delete_list(head);
    }

    ListLinkedSingle(const ListLinkedSingle& other)
        : head(copy_nodes(other.head)) { }

    void push_front(const int& elem) {
        Node* new_node = new Node{ elem, head };
        head = new_node;
    }

    void push_back(const int& elem);

    void pop_front() {
        assert(head != nullptr);
        Node* old_head = head;
        head = head->next;
        delete old_head;
    }

    void pop_back();

    int size() const;

    bool empty() const {
        return head == nullptr;
    };

    const int& front() const {
        assert(head != nullptr);
        return head->value;
    }

    int& front() {
        assert(head != nullptr);
        return head->value;
    }

    const int& back() const {
        return last_node()->value;
    }

    int& back() {
        return last_node()->value;
    }

    const int& at(int index) const {
        Node* result_node = nth_node(index);
        assert(result_node != nullptr);
        return result_node->value;
    }

    int& at(int index) {
        Node* result_node = nth_node(index);
        assert(result_node != nullptr);
        return result_node->value;
    }

    // La funci�n est� declarada aqu�, pero se implementa
    // m�s abajo
    void replicate(const ListLinkedSingle& ys);

    void display(std::ostream& out) const;
    void display() const {
        display(std::cout);
    }

private:
    Node* head;

    void delete_list(Node* start_node);
    Node* last_node() const;
    Node* nth_node(int n) const;
    Node* copy_nodes(Node* start_node) const;

};

ListLinkedSingle::Node* ListLinkedSingle::copy_nodes(Node* start_node) const {
    if (start_node != nullptr) {
        Node* result = new Node{ start_node->value, copy_nodes(start_node->next) };
        return result;
    }
    else {
        return nullptr;
    }
}

void ListLinkedSingle::delete_list(Node* start_node) {
    if (start_node != nullptr) {
        delete_list(start_node->next);
        delete start_node;
    }
}

void ListLinkedSingle::push_back(const int& elem) {
    Node* new_node = new Node{ elem, nullptr };
    if (head == nullptr) {
        head = new_node;
    }
    else {
        last_node()->next = new_node;
    }
}

void ListLinkedSingle::pop_back() {
    assert(head != nullptr);
    if (head->next == nullptr) {
        delete head;
        head = nullptr;
    }
    else {
        Node* previous = head;
        Node* current = head->next;

        while (current->next != nullptr) {
            previous = current;
            current = current->next;
        }

        delete current;
        previous->next = nullptr;
    }
}

int ListLinkedSingle::size() const {
    int num_nodes = 0;

    Node* current = head;
    while (current != nullptr) {
        num_nodes++;
        current = current->next;
    }

    return num_nodes;
}


ListLinkedSingle::Node* ListLinkedSingle::last_node() const {
    assert(head != nullptr);
    Node* current = head;
    while (current->next != nullptr) {
        current = current->next;
    }
    return current;
}

ListLinkedSingle::Node* ListLinkedSingle::nth_node(int n) const {
    assert(0 <= n);
    int current_index = 0;
    Node* current = head;

    while (current_index < n && current != nullptr) {
        current_index++;
        current = current->next;
    }

    return current;
}

void ListLinkedSingle::display(std::ostream& out) const {
    out << "[";
    if (head != nullptr) {
        out << head->value;
        Node* current = head->next;
        while (current != nullptr) {
            out << ", " << current->value;
            current = current->next;
        }
    }
    out << "]";
}


// Implementa aqu� la funci�n pedida. No olvides indicar el coste.
void ListLinkedSingle::replicate(const ListLinkedSingle& ys) {

    /*Sin nodo fantasma*/

    if (this->empty()||ys.empty())
    {
        return;
    }

    Node* this_curr = this->head;
    Node* this_prev = nullptr;
    Node* other_curr = ys.head;

    while (this_curr !=nullptr)
    {

        if (other_curr->value ==0)
        {
            Node* aux = this_curr->next;
            if (this_curr == this->head)
            {
                delete this_curr;
                this->head = aux;
                this_curr = aux;
            }
            else
            {
                this_prev->next = aux;
                delete this_curr;
                this_curr = aux;
            }

            other_curr = other_curr->next;
        }
        else if (other_curr->value==1)
        {
            this_prev = this_curr;
            this_curr = this_curr->next;
            other_curr = other_curr->next;
        }
        else {

            for (int i = 0; i < other_curr->value-1; i++)
            {
                Node* nuevo = new Node{this_curr->value, this_curr};
                if (this_curr == this->head)
                {
                    this->head = nuevo;
                    this_prev = nuevo;
                }
                else
                {

                    this_prev->next = nuevo;
                    this_prev = nuevo;
                }
                

            }
            this_prev = this_curr;
            this_curr = this_curr->next;
            other_curr = other_curr->next;

        }

    }
}


void tratar_caso() {
    // Para reducir el coste de nuestro programa, nos dan los n�meros en el orden inverso.

    ListLinkedSingle xs, ys;

    int numElementos;

    cin >> numElementos;

    for (int i = 0; i < numElementos; i++)//O(numElementos) lineal en el n�mero de elementos porque se hacen operaciones constantes numElementos veces.
    {
        int num;
        cin >> num;
        xs.push_front(num);//O(1)
    }
    for (int i = 0; i < numElementos; i++)//O(numElementos) lineal en el n�mero de elementos porque se hacen operaciones constantes numElementos veces.
    {
        int num;
        cin >> num;
        ys.push_front(num);//O(1)
    }

    xs.replicate(ys);
    xs.display(cout);

    cout << "\n";

}


int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    int numCasos;

    cin >> numCasos;

    for (int i = 0; i < numCasos; i++)
    {
        tratar_caso();
    }

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    // Descomentar si se trabaja en Windows
    system("PAUSE");
#endif

    return 0;
}