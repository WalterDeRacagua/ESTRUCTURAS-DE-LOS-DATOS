#include <iostream>
#include <fstream>
#include <cassert>

using namespace std;

class ListLinkedSingle {
private:
	struct Node {
		int value;
		Node* next;
	};
	Node* head;
public:
    ListLinkedSingle() : head(nullptr) { }
    ~ListLinkedSingle() {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }
    // Nuevo constructor. Se implementar� fuera de la clase.
    // Mira m�s abajo para ver d�nde tienes que implementarlo.

	void duplicate();
    void display(std::ostream& out) const;
    void insertar(int val) {

        Node* new_node = new Node{ val,head->next};

    }
    

    void push_back(const int& elem) {
        Node* new_node = new Node{ elem, nullptr };
        if (head == nullptr) {
            head = new_node;
        }
        else {
            last_node()->next = new_node;
        }
    }

    Node* last_node() const;
};

void ListLinkedSingle::duplicate()
{
    Node* current= this->head;

    while (current != nullptr)
    {
        Node* dup = new Node;
        dup->value = current->value;
        dup->next = current->next;
        current->next = dup;

        current = dup->next;
    }

}
void ListLinkedSingle::display(std::ostream& out) const {
    cout << "[";
    if (head != nullptr) {
        out << head->value;
        Node* current = head->next;
        while (current != nullptr) {
            out << ", " << current->value;
            current = current->next;
        }
    }
    out << "]";
}

ListLinkedSingle::Node* ListLinkedSingle::last_node() const {
    assert(head != nullptr);
    Node* current = head;
    while (current->next != nullptr) {
        current = current->next;
    }
    return current;
}


void tratar_caso() {

    ListLinkedSingle list;

    int valor = 0;

    cin >> valor;

    while (valor !=0)
    {
        list.push_back(valor);
        cin >> valor;
    }

    list.duplicate();

    list.display(cout);

    cout << endl;

}



int main() {

    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
    // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
    // �til para no tener que teclear los casos de prueba por teclado cada vez
    // que ejecutas el programa.
    //
    // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
    // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // La entrada comienza con el n�mero de casos de prueba.
    int num_casos;
    cin >> num_casos;

    // Llamamos tantas veces a `tratar_caso` como nos diga el n�mero.
    for (int i = 0; i < num_casos; i++) {
        tratar_caso();
    }

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
