/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 *              Facultad de Inform�tica
 *         Universidad Complutense de Madrid
 * ---------------------------------------------------
 */

 /*
  * MUY IMPORTANTE: Para realizar este ejercicio solo pod�is
  * modificar el c�digo contenido entre las etiquetas <answer>
  * y </answer>. Toda modificaci�n fuera de esas etiquetas est�
  * prohibida, pues no se tendr� en cuenta para la correcci�n.
  *
  * Tampoco esta permitido modificar las l�neas que contienen
  * las etiquetas <answer> y </answer>, obviamente :-)
  */


  //@ <answer>
  /*
    Indica el nombre y apellidos de los componentes del grupo
    ---------------------------------------------------------
    Componente 1:
    Componente 2:
  */
  //@ </answer>

#include <iostream>
#include <fstream>
#include <cassert>
#include <string> 


/*
  Implementaci�n de listas enlazadas simples vista en clase.

  https://github.com/manuelmontenegro/ED/tree/main/lineales/list_linked_single_v2

  En este caso, los valores contenidos en los nodos no son de tipo entero,
  sino de tipo char, porque es lo que requiere el ejercicio. En la Semana 4
  veremos c�mo hacer que una misma implementaci�n del TAD Lista pueda
  aplicarse a distintos tipos de elementos (int, char, string, etc.)
*/
class ListLinkedSingle {
private:
    struct Node {
        char value;
        Node* next;
    };

public:
    ListLinkedSingle() : head(nullptr) { }

    // Nuevo constructor. Se implementar� fuera de la clase.
    // Mira m�s abajo para ver d�nde tienes que implementarlo.
    ListLinkedSingle(const std::string& text);

    ~ListLinkedSingle() {
        delete_list(head);
    }

    ListLinkedSingle(const ListLinkedSingle& other)
        : head(copy_nodes(other.head)) { }

    void push_front(const char& elem) {
        Node* new_node = new Node{ elem, head };
        head = new_node;
    }

    void push_back(const char& elem);

    void pop_front() {
        assert(head != nullptr);
        Node* old_head = head;
        head = head->next;
        delete old_head;
    }

    void pop_back();

    int size() const;

    bool empty() const {
        return head == nullptr;
    };

    const char& front() const {
        assert(head != nullptr);
        return head->value;
    }

    char& front() {
        assert(head != nullptr);
        return head->value;
    }

    const char& back() const {
        return last_node()->value;
    }

    char& back() {
        return last_node()->value;
    }

    const char& at(int index) const {
        Node* result_node = nth_node(index);
        assert(result_node != nullptr);
        return result_node->value;
    }

    char& at(int index) {
        Node* result_node = nth_node(index);
        assert(result_node != nullptr);
        return result_node->value;
    }

    void display(std::ostream& out) const;
    void display() const {
        display(std::cout);
    }

    // M�todo `destripar`. Se implementar� fuera de la clase.
    // Mira m�s abajo para ver d�nde tienes que implementarlo.
    void destripar(ListLinkedSingle& dest);

private:
    Node* head;

    void delete_list(Node* start_node);
    Node* last_node() const;
    Node* nth_node(int n) const;
    Node* copy_nodes(Node* start_node) const;

};

ListLinkedSingle::Node* ListLinkedSingle::copy_nodes(Node* start_node) const {
    if (start_node != nullptr) {
        Node* result = new Node{ start_node->value, copy_nodes(start_node->next) };
        return result;
    }
    else {
        return nullptr;
    }
}

void ListLinkedSingle::delete_list(Node* start_node) {
    if (start_node != nullptr) {
        delete_list(start_node->next);
        delete start_node;
    }
}

void ListLinkedSingle::push_back(const char& elem) {
    Node* new_node = new Node{ elem, nullptr };
    if (head == nullptr) {
        head = new_node;
    }
    else {
        last_node()->next = new_node;
    }
}

void ListLinkedSingle::pop_back() {
    assert(head != nullptr);
    if (head->next == nullptr) {
        delete head;
        head = nullptr;
    }
    else {
        Node* previous = head;
        Node* current = head->next;

        while (current->next != nullptr) {
            previous = current;
            current = current->next;
        }

        delete current;
        previous->next = nullptr;
    }
}

int ListLinkedSingle::size() const {
    int num_nodes = 0;

    Node* current = head;
    while (current != nullptr) {
        num_nodes++;
        current = current->next;
    }

    return num_nodes;
}


ListLinkedSingle::Node* ListLinkedSingle::last_node() const {
    assert(head != nullptr);
    Node* current = head;
    while (current->next != nullptr) {
        current = current->next;
    }
    return current;
}

ListLinkedSingle::Node* ListLinkedSingle::nth_node(int n) const {
    assert(0 <= n);
    int current_index = 0;
    Node* current = head;

    while (current_index < n && current != nullptr) {
        current_index++;
        current = current->next;
    }

    return current;
}

void ListLinkedSingle::display(std::ostream& out) const {
    out << "[";
    if (head != nullptr) {
        out << head->value;
        Node* current = head->next;
        while (current != nullptr) {
            out << ", " << current->value;
            current = current->next;
        }
    }
    out << "]";
}

//@ <answer>
//---------------------------------------------------------------
// Modificar a partir de aqu�
// --------------------------------------------------------------

// Implementa el constructor y el m�todo pedidos. Indica y justifica el coste
// antes de cada implementaci�n, mediante un comentario.


/*Constructor*/
ListLinkedSingle::ListLinkedSingle(const std::string& text): ListLinkedSingle() {

    /*PRIMERO HACEMOS QUE LLAME AL CONSTRUCTOR POR DEFECTO PARA QUE INICIE HEAD A NULLPOINTER*/

    //Si la cadena es vac�a, dejamos head en nullptr.
    
    //Si no es vac�a...
    if (text.length()!=0)//Coste lineal en el n�mero de caracteres de la cadena
    {
        //Creamos un nodo que sea el primer caracter

        this->head = new Node{ text[0], nullptr };//Creamos nodo y que su siguiente sea null

        //La variable last
        Node* last = head;

        //Ahora vamos con los siguientes

        for (int i = 1; i < text.length(); i++)
        {
            Node* nuevo = new Node{ text[i], nullptr };
            last->next = nuevo;//Last apunta al nodo creado
            last = nuevo;// Pasa a ser el nodo creado
        }
    }

    //LO HEMOS HECHO AS� PARA EVITAR UTILIZAR PUSH BACK YA QUE TENDR�A COSTE CUADR�TICO.
    //PERO PODEMOS VER QUE PUSH_FRONT TIENE COSTE CONSTANTE Y POR TANTO SE QUEDAR�A LINEAL
    // POR LO QUE OTRA MANERA M�S SENCILLA DE HACERLO SER�A EMPEZAR A LEER LA CADENA POR ATR�S.
    /*
    for (int i = text.size()-1; i >= 0; i--)
    {
        this->push_front(text[i]);
    }
    */
   
}



void ListLinkedSingle::destripar(ListLinkedSingle& dest) {

    Node* prev = nullptr;
    Node* current = head;

    //Buscamos el primer nodo que tenga una letra
    while (current!= nullptr&& current->value >= '0'&& current->value <='9')
    {
        prev = current;
        current = current->next;
    }

    //Current ahora mismo apuntar�a a la primera letra. Prev al �ltimo n�mero
    //o a nullptr si la lista empiez por letra

    //Ahora debemos actualizar las cabezas de ambas listas

    if (prev !=nullptr)
    {
        dest.head = this->head;
        this->head = current;
    }

    //Ahora tenemos que buscar la �ltima letra . Cada vez que encontramos una
    //letra la guardamos en "last_letter"

    Node* last_letter = nullptr;

    while (current!=nullptr)
    {
        if (current->value <'0'||current->value >'9')
        {
            last_letter = current;
        }
        current = current->next;
    }


    //En este punto, last letter apunta a la �ltima letra o a nullptr.

    Node* rest = nullptr;

    if (last_letter != nullptr)
    {
        rest = last_letter->next;
        last_letter->next = nullptr;
    }


    if (prev != nullptr)
    {
        prev->next = rest;
    }
    else
    {
        dest.head = rest;
    }
}

using namespace std;

// Implementa aqu� la funci�n para tratar UN caso de prueba. La funci�n `main`
// llamar� a esta funci�n `tratar_caso` tantas veces como casos de prueba hay
// en la entrada.

void tratar_caso() {

    string cadena;

    cin >> cadena;

    ListLinkedSingle palabra(cadena);
    ListLinkedSingle destripar;//Cadena inicializa head a nullptr.
    palabra.destripar(destripar);

    palabra.display();
    cout << endl;
    destripar.display();
    cout << endl;

}

//---------------------------------------------------------------
// No modificar por debajo de esta l�nea
// --------------------------------------------------------------
//@ </answer>


int main() {

    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
    // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
    // �til para no tener que teclear los casos de prueba por teclado cada vez
    // que ejecutas el programa.
    //
    // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
    // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // La entrada comienza con el n�mero de casos de prueba.
    int num_casos;
    cin >> num_casos;

    // Llamamos tantas veces a `tratar_caso` como nos diga el n�mero.
    for (int i = 0; i < num_casos; i++) {
        tratar_caso();
    }

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
