/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 *              Facultad de Inform�tica
 *         Universidad Complutense de Madrid
 * ---------------------------------------------------
 */


 /*
  * MUY IMPORTANTE: Para realizar este ejercicio solo pod�is
  * modificar el c�digo contenido entre las etiquetas <answer>
  * y </answer>. Toda modificaci�n fuera de esas etiquetas est�
  * prohibida, pues no se tendr� en cuenta para la correcci�n.
  *
  * Tampoco esta permitido modificar las l�neas que contienen
  * las etiquetas <answer> y </answer>, obviamente :-)
  */


  //@ <answer>
  /*
    Indica el nombre y apellidos de los componentes del grupo
    ---------------------------------------------------------
    Componente 1:
    Componente 2:
  */
  //@ </answer>


  // A�ade los #include que necesites
#include <iostream>
#include <fstream>
#include <string>
#include <utility>
#include <list>
#include <stack>

using namespace std;


//@ <answer>
// Implementa la funci�n pedida aqu�.
// Para ello utiliza las librer�as de la STL.
//
// No olvides justificar brevemente el coste.
//

void reconstruir(list<int>& lista) {

    stack<int> pila_equilibrados;

    auto it = lista.begin();

    while (it != lista.end())
    {
        if (*it <0&& pila_equilibrados.empty())
        {
            it = lista.erase(it);//O(1)
        }
        else if (*it <0 && !pila_equilibrados.empty())
        {
            //Si el valor del iterador es igual al opuesto de lo que hay en la pila entonces avanzo iterador, si no borramos
            if (*it == -pila_equilibrados.top())
            {
                pila_equilibrados.pop();
                ++it;
            }
            else
            {
                it = lista.erase(it);
            }

        }
        else if (*it ==0 && !pila_equilibrados.empty())
        {
            //Entonces debemos de cambiar el valor del 0 por el opuesto al que hay en la pila
            *it = -pila_equilibrados.top();//O(1)
            pila_equilibrados.pop();//O(1)
            ++it;
        }
        else if (*it >0)
        {
            pila_equilibrados.push(*it);
            ++it;
        }
    }

    while (!pila_equilibrados.empty())//Lineal en el n�mero de elementos restantes de la pila
    {
        int valor = -pila_equilibrados.top();//O(1)
        pila_equilibrados.pop();//O(1)
        lista.push_back(valor);//O(1)
    }


}

//---------------------------------------------------------------
// No modificar nada por debajo de esta l�nea
// -------------------------------------------------------------
//@ </answer>


// Funci�n que trata un caso de prueba.
bool tratar_caso() {
    int num_elems;
    list<int> lista;

    cin >> num_elems;
    if (cin.eof()) return false;

    // Leemos lista
    for (int i = 0; i < num_elems; i++) {
        int elem;
        cin >> elem;
        lista.push_back(elem);
    }

    // Llamamos a la funci�n pedida
    reconstruir(lista);

    // Imprimimos el resultado
    bool primero = true;
    for (auto x : lista) {
        cout << (primero ? "" : " ") << x;
        primero = false;
    }
    cout << "\n";

    return true;
}


int main() {
    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
    // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
    // �til para no tener que teclear los casos de prueba por teclado cada vez
    // que ejecutas el programa.
    //
    // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
    // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // Ejecutamos tratar_caso() hasta que nos devuelva `false`
    while (tratar_caso()) {}

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
