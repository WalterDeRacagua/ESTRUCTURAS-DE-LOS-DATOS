// Par�ntesis equilibrados
// -----------------------
// Estructuras de datos


/*
  En este ejercicio solamente pueden utilizarse las colecciones vistas durante
  esta semana: pilas, colas, o dobles colas.

  En lugar de utilizar las implementaciones vistas en clase, utilizad las que
  vienen implementadas en la biblioteca est�ndar de C++, que son las
  siguientes:

  - queue, definida en el fichero de cabecera <queue>
    Documentaci�n: https://en.cppreference.com/w/cpp/container/queue

  - stack, definida en el fichero de cabecera <stack>
    Documentaci�n: https://en.cppreference.com/w/cpp/container/stack

  - deque, definida en el fichero de cabecera <deque>
    Documentaci�n: https://en.cppreference.com/w/cpp/container/deque

  A�ade los #include con los ficheros de cabecera del TAD o los TADs que
  vais a utilizar.
*/


#include <iostream>
#include <cassert>
#include <string> 
#include <fstream>
#include <cstdlib>
#include <list>
#include <stack>
#include <string>
#include <sstream>

using namespace std;



// Implementa aqu� la funci�n para tratar UN caso de prueba. La funci�n
// devuelve false si, en lugar de encontrarse con un caso de prueba, se ha
// topado con la marca de fin de fichero. Por el contrario, si se ha
// encontrado con un caso de prueba y lo ha procesado, devuelve true.

// No olvides indicar y justificar el coste de la funci�n.

bool tratar_caso() {
    string str;
    stack<char> pila;
    getline(cin, str);
    if (cin.eof()) return false;

    int i = 0;
    bool equilibrado = true;
    while (i < str.length() && equilibrado) {
        switch (str[i]) {
        case '{':
        case '[':
        case '(':
            pila.push(str[i]);
            break;

        case '}':
            if (pila.empty() || pila.top() != '{') equilibrado = false;
            else pila.pop();
            break;
        case ']':
            if (pila.empty() || pila.top() != '[') equilibrado = false;
            else pila.pop();
            break;
        case ')':
            if (pila.empty() || pila.top() != '(') equilibrado = false;
            else pila.pop();
            break;
        }
        i++;
    }

    if (equilibrado && !pila.empty()) equilibrado = false;

    cout << (equilibrado ? "SI" : "NO") << endl;

    return true;
}


int main() {
#ifndef DOMJUDGE
    ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
    while (tratar_caso())  {   }




#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;

} // main