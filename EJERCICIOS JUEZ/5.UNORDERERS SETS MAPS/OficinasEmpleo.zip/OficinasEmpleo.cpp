// Oficinas de empleo
// ------------------
// Estructuras de datos

// A�ade los #include que creas necesarios

#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <unordered_map>
#include <set>
#include<map>


using namespace std;


class OficinaEmpleo {
public:

    void altaOficina(const string& nombre, const string& empleo) {//O(log(N))

        if (this->persona_posicion[nombre].count(empleo))//O(1)
        {
            //No se vuelve a apuntar
            return;
        }

        //Introduzco al final de la lista a la persona
        auto it = this->empleo_persona[empleo].insert(this->empleo_persona[empleo].end(), nombre);//O(1)
        // Asegurarse de que la estructura para la persona existe
        this->persona_posicion[nombre][empleo] =it;//O(log(N)


    }

    string ofertaEmpleo(string empleo) {//O(Empleos), siendo empleo el n�mero de empleos de la persona que se lleva la oferta.

        if (!this->empleo_persona.count(empleo))//O(1)
        {
            throw domain_error("No existen personas apuntadas a este empleo");
        }

        auto& trabajo = this->empleo_persona.at(empleo);//O(1)
        string persona = trabajo.front();//O(1)

        for (auto empleos: this->persona_posicion[persona])//O(Empleo), siendo empleo el n�mero de empleos.
        {
            this->empleo_persona[empleos.first].erase(empleos.second);//O(1)

            if (this->empleo_persona[empleos.first].empty())//O(1)
            {
                this->empleo_persona.erase(empleos.first);//O(1)
            }

        }

        this->persona_posicion.erase(persona);//O(1)


        return persona;
    }

    vector<string> listadoEmpleos(string persona) {

        if (!this->persona_posicion.count(persona))
        {
            throw domain_error("Persona inexistente");
        }

        vector<string> trabajos;

        for (auto empleos: this->persona_posicion[persona])//Este for en total tendr� un coste O(Empleos) siendo Empleos el n�mero de empleos que tiene la persona "persona".
        {

            trabajos.push_back(empleos.first);//O(1)
        }


        return trabajos;
    }

private:
    
    unordered_map<string, list<string>> empleo_persona;
    unordered_map<string, map<string, list<string>::iterator>> persona_posicion;//Una lista de iteradores
};






bool tratar_caso() {
    OficinaEmpleo oe;
    string comando;
    cin >> comando;

    if (cin.eof()) return false;

    while (comando != "FIN") {
        try {
            if (comando == "altaOficina") {
                string nombre, empleo;
                cin >> nombre >> empleo;
                oe.altaOficina(nombre, empleo);
            }
            else if (comando == "ofertaEmpleo") {
                string empleo;
                cin >> empleo;
                string persona = oe.ofertaEmpleo(empleo);
                cout << empleo << ": " << persona << "\n";
            }
            else if (comando == "listadoEmpleos") {
                string persona;
                cin >> persona;
                vector<string> empleos = oe.listadoEmpleos(persona);
                cout << persona << ":";
                for (const string& e : empleos) {
                    cout << " " << e;
                }
                cout << "\n";
            }
        }
        catch (std::exception& e) {
            cout << "ERROR: " << e.what() << "\n";
        }
        cin >> comando;
    }
    cout << "---\n";

    return true;
}

int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    while (tratar_caso()) {}


#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    // Descomentar si se trabaja en Windows
    system("PAUSE");
#endif

    return 0;
}