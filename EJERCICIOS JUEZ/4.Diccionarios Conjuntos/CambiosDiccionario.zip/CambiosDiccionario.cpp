// Actualizaci�n de un diccionario
// -------------------------------
// Estructuras de datos


// Utiliza las clases de la STL de C++ para este problema
// A�ade los #include que creas necesarios

#include <iostream>
#include <cassert>
#include <fstream>
#include <map>
#include <string>
#include <sstream>
#include <set>

using namespace std;


// 
// Implementa a continuaci�n la funci�n que trata un caso de prueba.
//

void tratar_caso() {
    
    string linea1, linea2;
    map<string, int> mapa1;
    map<string, int> mapa2;
    set<string> anyadidas,eliminadas,cambiadas;

    getline(cin, linea1);
    getline(cin, linea2);

    istringstream iss1(linea1);
    string clave;
    int valor;

    while (iss1>> clave>>valor)
    {
        mapa1[clave] = valor;
    }

    istringstream iss2(linea2);

    while (iss2>> clave>>valor)
    {
        mapa2[clave] = valor;
    }

    for (auto[k,v]: mapa2)
    {
        if (!mapa1.count(k))
        {
            anyadidas.insert(k);
        }
        else
        {
            if (v != mapa1[k])
            {
                cambiadas.insert(k);
            }
        }
    }


    for (auto[k,v]: mapa1)
    {
        if (!mapa2.count(k))
        {
            eliminadas.insert(k);
        }
    }

    if (anyadidas.empty()&& cambiadas.empty()&&eliminadas.empty())
    {
        cout << "Sin cambios" << endl;
    }
    else
    {
        if (!anyadidas.empty())
        {
            cout << "+ ";
            for (auto s: anyadidas)
            {
                cout << s << " ";
            }
            cout << endl;
        }
        if (!eliminadas.empty())
        {
            cout << "- ";
            for (auto s: eliminadas)
            {
                cout << s << " ";
            }
            cout << endl;
        } 
        if (!cambiadas.empty())
        {
            cout << "* ";
            for (auto s: cambiadas)
            {
                cout << s << " ";
            }
            cout << endl;
        }

    }

    cout << "---\n";
}


int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // La entrada comienza con el n�mero de casos de prueba.

    // Llamamos a `tratar_caso` tantas veces como el n�mero anterior.
    int num_casos;
    cin >> num_casos;
    cin.ignore(); // Leemos todos los caracteres hasta el fin de l�nea

    for (int i = 0; i < num_casos; i++) {
        tratar_caso();
    }

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
