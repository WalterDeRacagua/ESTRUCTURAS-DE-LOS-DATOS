/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 *              Facultad de Inform�tica
 *         Universidad Complutense de Madrid
 * ---------------------------------------------------
 */

 /*
  * MUY IMPORTANTE: Para realizar este ejercicio solo pod�is
  * modificar el c�digo contenido entre las etiquetas <answer>
  * y </answer>. Toda modificaci�n fuera de esas etiquetas est�
  * prohibida, pues no se tendr� en cuenta para la correcci�n.
  *
  * Tampoco esta permitido modificar las l�neas que contienen
  * las etiquetas <answer> y </answer>, obviamente :-)
  */


  //@ <answer>
  /*
    Indica el nombre y apellidos de los componentes del grupo
    ---------------------------------------------------------
    Componente 1: Sergio S�nchez Carrasco
    Componente 2: Lucas S�nchez Marit�n
  */
  //@ </answer>

  /*
    En este ejercicio solamente pueden utilizarse las colecciones vistas durante
    esta semana: pilas, colas, o dobles colas.

    En lugar de utilizar las implemtaciones vistas en clase, utilizad las que
    vienen implementadas en la biblioteca est�ndar de C++, que son las
    siguientes:

    - queue, definida en el fichero de cabecera <queue>
      Documentaci�n: https://en.cppreference.com/w/cpp/container/queue

    - stack, definida en el fichero de cabecera <stack>
      Documentaci�n: https://en.cppreference.com/w/cpp/container/stack

    - deque, definida en el fichero de cabecera <deque>
      Documentaci�n: https://en.cppreference.com/w/cpp/container/deque

    A�ade los #include con los ficheros de cabecera del TAD o los TADs que
    vais a utilizar, aunque est�n fuera de las etiquetas <answer>...</answer>.
  */


#include <iostream>
#include <fstream>
#include <cassert>
#include <string> 
#include <utility>
#include <queue>


using namespace std;



//@ <answer>
// ----------------------------------------------
// Modificar a partir de aqu�
// ----------------------------------------------


// A�ade los tipos de datos auxiliares y funciones que necesites

struct tPersona
{
    char nivel{};
    int num_intentos = 0;
};


// Implementa aqu� la funci�n para tratar UN caso de prueba. La funci�n
// devuelve false si, en lugar de encontrarse con un caso de prueba, se ha
// topado con la marca de fin de fichero. Por el contrario, si se ha
// encontrado con un caso de prueba y lo ha procesado, devuelve true.

// No olvides indicar y justificar el coste de la funci�n.


int suspensosRestantes(queue<char>horasProfesores, queue<tPersona> alumnoExaminado, int vecesBucle) {

    int numSuspensosRestantes = alumnoExaminado.size();
    int i = 0;

    if (numSuspensosRestantes>0)
    {
        while (i<vecesBucle &&numSuspensosRestantes!=0)
        {
            if (horasProfesores.front() == 'G')//Siempre suspende
            {
                alumnoExaminado.front().num_intentos++;
                alumnoExaminado.push(alumnoExaminado.front());
                alumnoExaminado.pop();

            }
            else if (horasProfesores.front() == 'A')
            {
                if (alumnoExaminado.front().nivel == 'B')
                {
                    alumnoExaminado.pop(); //Eliminamos de la lista ese elemento
                    numSuspensosRestantes--;
                }
                else if (alumnoExaminado.front().nivel == 'M')
                {
                    alumnoExaminado.front().num_intentos++;
                    alumnoExaminado.push(alumnoExaminado.front());
                    alumnoExaminado.pop();
                }
            }
            else if (horasProfesores.front() == 'B')
            {
                if (alumnoExaminado.front().nivel == 'B')
                {
                    alumnoExaminado.pop(); //Eliminamos de la lista ese elemento
                    numSuspensosRestantes--;
                }
                else if (alumnoExaminado.front().nivel == 'M')
                {
                    if (alumnoExaminado.front().num_intentos < 2)
                    {
                        alumnoExaminado.front().num_intentos++;
                        alumnoExaminado.push(alumnoExaminado.front());
                        alumnoExaminado.pop();
                    }
                    else
                    {
                        alumnoExaminado.pop();
                        numSuspensosRestantes--;
                    }
                }
            }
            horasProfesores.push(horasProfesores.front());
            horasProfesores.pop();
            i++;
        }
    }

    /*
    Este algoritmo resuelve este problema utilizando un bucle while. Este bucle while se ejecuta hasta que
    i = vecesBucle -1, donde vecesBucle es el n�mero de horas disponibles al d�a N por el n�mero de d�as T. Dentro
    del bucle se realizan operaciones pop() y push(). Tanto las operaciones push como las operaciones pop en una cola
    tienen coste constante O(1). Como el coste de hacer las operaciones dentro del while siempre es constante y el bucle
    while se ejecuta N*T veces (vecesBucle veces), el coste total de nuestro algoritmo ser� lineal en vecesBucle o lineal
    en N*M: O(N*M) || O(vecesBucle).   
    
    */
    

    return numSuspensosRestantes;
}


bool tratar_caso() {
    
    int N = 0, M = 0, T = 0;

    cin >> N >> M >> T;

    if (!N&&!M&&!T)
    {
        return false;
    }

    queue<char> horasProfesores;
    queue<tPersona> alumnoExaminado;
        
    for (int i = 0; i < N; i++)//Coste lineal en el n�mero de elementos N, ya que en cada iteraci�n se realiza la operaci�n de push que tiene coste constante. Luego coste O(N)
    {
        char examinador;
        cin >> examinador;
        horasProfesores.push(examinador);//O(1)

    } 
    
    for (int i = 0; i < M; i++)//Coste lineal en el n�mero de elementos M, ya que en cada iteraci�n se producen asignaciones y una operaci�n de push que tiene coste constante. Luego coste O(M)
    {
        tPersona nuevaPersona;
        char nivel;
        cin >> nivel;
        nuevaPersona.nivel = nivel;
        alumnoExaminado.push(nuevaPersona);//O(1)
    } 

    int vecesBucle = N * T;

    cout << suspensosRestantes(horasProfesores, alumnoExaminado, vecesBucle)<< "\n";

    return true;
}

// ----------------------------------------------
// No modificar a partir de la l�nea
// ----------------------------------------------
//@ </answer>


int main() {
    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
    // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
    // �til para no tener que teclear los casos de prueba por teclado cada vez
    // que ejecutas el programa.
    //
    // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
    // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // Ejecutamos tratar_caso() hasta que nos devuelva `false`
    while (tratar_caso()) {}

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
