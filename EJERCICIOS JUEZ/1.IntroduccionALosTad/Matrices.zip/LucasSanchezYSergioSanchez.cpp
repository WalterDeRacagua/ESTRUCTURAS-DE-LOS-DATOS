/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 *              Facultad de Inform�tica
 *         Universidad Complutense de Madrid
 * ---------------------------------------------------
 */

 /*
   Indica el nombre y apellidos de los componentes del grupo
   ---------------------------------------------------------
   Componente 1: Sergio S�nchez
   Componente 2:Lucas S�nchez
 */

#include <iostream>
#include <fstream>
#include <vector>
#include <cassert>

using namespace std;

// Define aqu� la clase ToeplitzMatrix e implementa sus m�todos.
//
// No te olvides de indicar y justificar el coste del constructor y el coste de cada m�todo.

//He puesto los costes encima de las funciones. No las he implementado fuera porque son funciones con una implementaci�n muy corta.

class ToeplitzMatrix
{
public:
	//Funci�n de coste lineal en el n�mero de diagonales, ya que se hacen tantas asignaciones como diagonales.
	//Por tanto el orden de la funci�n es: O(n+m)
	ToeplitzMatrix(int i, int j, int v) {
		
		this->n = i;
		this->m = j;
		this->diag.resize(n + m - 1, v);//Relleno todas las diagonales de v. No me deja hacer this->diag(n+m-1,v) en el juez

	}
	//Funci�n de tipo const porque no altera el estado de ning�n objeto. Solo devuelve un valor. Por tanto es de coste constante. O(1).
	int get(int i, int j)const {//No modifica el estado de los objetos
			
		return this->diag[j-i+n-1];
	}
	//Funci�n que NO puede ser de tipo const porque altera el estado del objeto diag. Solo asigna un valor y, por tanto esto es de coste constante O(n1)
	void set(int i, int j, int v) {//Asignaci�n de los valores a las diagonales

		this->diag[j - i + n - 1] = v; 
	}

private:

	int n;
	int m;
	vector<int>diag;//Con una matriz no me funcionaba
};


bool tratar_caso() {
	// Implementa el c�digo para tratar un caso de prueba.

	int i = 0, j = 0, v = 0;

	cin >> i >> j >> v;


	// Esta funci�n debe devolver `false` si, en lugar de un caso de prueba,
	// se ha encontrado con la marca de fin de entrada (0 0 0).
	if (i==0&&j==0&&v==0)
	{
		return false;
	}

	ToeplitzMatrix matriz(i, j, v);

	string op;
	cin >> op;

	while (op != "FIN") 
	{
		cin >> i >> j;
		if (op=="set")
		{
			cin >> v;

			matriz.set(i, j, v);
		}
		else if (op == "get")
		{
			cout << matriz.get(i, j) << endl;
		}
		cin >> op;
	}
	cout << "---\n";

	// En caso contrario, debe procesar el caso de prueba y devolver `true`.
	return true;
}

int main() {
#ifndef DOMJUDGE
	std::ifstream in("sample.in");
	auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

	while (tratar_caso()) {}

#ifndef DOMJUDGE
	std::cin.rdbuf(cinbuf);
#endif
	return 0;
}
