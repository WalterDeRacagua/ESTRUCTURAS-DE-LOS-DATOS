// Autoescuela
// -----------
// Estructuras de datos

// A�ade los #include que creas necesarios

#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <set>
#include <unordered_set>

using namespace std;


class Autoescuela {
public:
    Autoescuela() {

    }

    void alta(const string& alumno, const string& profesor) {//O(log(N))

        if (!this->alumnos.count(alumno))
        {
            this->alumnos[alumno] = 0;//O(1)
            this->profesores[profesor].insert(alumno);//O(log(N)) siendo N el numero de alumnos
            this->alumno_que_profesor[alumno] = profesor; //O(1)

        }
        else
        {
            auto p = this->alumno_que_profesor[alumno];//esto me da el alumno del profesor. O(1)
            this->profesores[p].erase(alumno);//O(1)
            this->profesores[profesor].insert(alumno);//O(log(N))
            this->alumno_que_profesor[alumno] = profesor;//O(1)           
        }
      
    }

    bool es_alumno(const string& alumno, const string& profesor) const {//O(1)

        return this->alumno_que_profesor.at(alumno) == profesor; //O(1)
    }

    int puntuacion(const string& alumno) const {//O(1)

        if (!this->alumno_que_profesor.count(alumno))//O(1)
        {
            throw domain_error("El alumno " + alumno + " no esta matriculado");
        }

        return this->alumnos.at(alumno); //O(1)
    }

    void actualizar(const string& alumno, int puntos) {//O(1)

        if (!alumno_que_profesor.count(alumno))//O(1)
        {
            throw domain_error("El alumno " + alumno + " no esta matriculado");
        }
    
        this->alumnos[alumno] += puntos;//O(1)

    }

    vector<string> examen(const string& profesor, int minimo_puntos) const {

        if (!profesores.count(profesor))
        {
            return{};
        }
        vector<string> alumnos_examinables;

        for (string alumno: this->profesores.at(profesor))//recorro los profesores. //Recorro log(N) veces
        {
            if (this->alumnos.at(alumno) >= minimo_puntos)
            {
                alumnos_examinables.push_back(alumno);
            }
        }

        return alumnos_examinables;
    }

    void aprobar(const string& alumno) {//O(log(N))
        if (!this->alumno_que_profesor.count(alumno))
        {
            throw domain_error("El alumno " + alumno + " no esta matriculado");
        }
        string profesor = this->alumno_que_profesor.at(alumno);//O(1)
        this->alumnos.erase(alumno); //O(1)
        this->alumno_que_profesor.erase(alumno);//O(1)
        this->profesores[profesor].erase(alumno);//O(log(N))

    }


private:
    // A�ade los atributos y m�todos privados necesarios

    unordered_map<string, set<string>> profesores;
    unordered_map<string, int> alumnos;
    unordered_map<string, string> alumno_que_profesor;
};


bool tratar_caso() {
    string operacion;
    cin >> operacion;
    if (cin.eof()) return false;

    Autoescuela ae;

    while (operacion != "FIN") {
        try {
            if (operacion == "alta") {
                string alumno, profesor;
                cin >> alumno >> profesor;
                ae.alta(alumno, profesor);
            }
            else if (operacion == "es_alumno") {
                string alumno, profesor;
                cin >> alumno >> profesor;
                if (ae.es_alumno(alumno, profesor)) {
                    cout << alumno << " es alumno de " << profesor << endl;
                }
                else {
                    cout << alumno << " no es alumno de " << profesor << endl;
                }
            }
            else if (operacion == "puntuacion") {
                string alumno;
                cin >> alumno;
                int puntuacion = ae.puntuacion(alumno);
                cout << "Puntuacion de " << alumno << ": " << puntuacion << endl;
            }
            else if (operacion == "actualizar") {
                string alumno;
                int puntuacion;
                cin >> alumno >> puntuacion;
                ae.actualizar(alumno, puntuacion);
            }
            else if (operacion == "examen") {
                string profesor;
                int minimo_puntos;
                cin >> profesor >> minimo_puntos;
                cout << "Alumnos de " << profesor << " a examen:" << endl;
                for (const string& nombre : ae.examen(profesor, minimo_puntos)) {
                    cout << nombre << endl;
                }
            }
            else if (operacion == "aprobar") {
                string alumno;
                cin >> alumno;
                ae.aprobar(alumno);
            }
        }
        catch (std::exception& e) {
            cout << "ERROR" << endl;
        }

        cin >> operacion;
    }

    cout << "---\n";
    return true;
}


int main() {
    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
    // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
    // �til para no tener que teclear los casos de prueba por teclado cada vez
    // que ejecutas el programa.
    //
    // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
    // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // Llamamos a `tratar_caso` hasta que se agoten los casos de prueba
    while (tratar_caso()) {}

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}