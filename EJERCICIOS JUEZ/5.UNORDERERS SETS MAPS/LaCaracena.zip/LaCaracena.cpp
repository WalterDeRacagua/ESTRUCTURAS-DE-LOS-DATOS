/*
 * ---------------------------------------------------------------
 *                 ESTRUCTURAS DE DATOS - EXAMEN FINAL
 *                   CONVOCATORIA EXTRAORDINARIA
 * ---------------------------------------------------------------
 *                            Ejercicio 3
 * ---------------------------------------------------------------
 */


 // Nombre y apellidos: ________________________________________  

#include <iostream>
#include <fstream>
#include <cassert>
#include <vector>
#include <utility>
#include <unordered_map>
#include <map>
#include <deque>
#include <list>
// A�ade los #include que necesites

using namespace std;

/*
 * Implementaci�n del TAD Restaurante
 */


#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <unordered_map>
#include <set>
#include <deque>
#include <queue>
#include <list>
#include <vector>

using namespace std;

class Restaurante {
public:

    void nueva_mesa(int num) {

        if (mesas.count(num)) throw domain_error("Mesa ocupada");

        mesas[num] = mesa();
    }

    void nuevo_pedido(int mesa, const string& plato) {

        if (!mesas.count(mesa)) throw domain_error("Mesa vacia");

        pedido p = pedido(mesa, plato);

        platos.push_front(p);

        mesas[mesa].pedidosMesa[plato].push_front(platos.begin());

    }

    void cancelar_pedido(int mesa, const string& plato) {

        if (!mesas.count(mesa)) throw domain_error("Mesa vacia");

        if (!mesas[mesa].pedidosMesa.count(plato)) throw domain_error("Producto no pedido por la mesa");

        platos.erase(mesas[mesa].pedidosMesa[plato].front());

        deque<list<pedido>::iterator>& l = mesas[mesa].pedidosMesa[plato];

        l.pop_front();

        if (l.empty()) mesas[mesa].pedidosMesa.erase(plato);

    }

    pair<int, string> servir() {

        if (platos.empty()) throw domain_error("No hay pedidos pendientes");

        pedido p = platos.back();

        platos.pop_back();

        deque<list<pedido>::iterator>& l = mesas[p.numMesa].pedidosMesa[p.name];

        l.pop_back();

        if (l.empty()) mesas[p.numMesa].pedidosMesa.erase(p.name);

        return { p.numMesa, p.name };
    }

    vector<string> que_falta(int num) const {

        if (!mesas.count(num)) throw domain_error("Mesa vacia");

        vector<string> plat;

        for (const auto& [k, v] : mesas.at(num).pedidosMesa) plat.push_back(k);

        return plat;
    }

private:

    struct pedido {

        int numMesa;
        string name;

        pedido(int mesa, string nombre) : numMesa(mesa), name(nombre) { }
    };

    struct mesa {
        map<string, deque<list<pedido>::iterator>> pedidosMesa;
    };

    list<pedido> platos;
    unordered_map<int, mesa> mesas;
};

//---------------------------------------------------------------
// No modificar nada por debajo de esta l�nea
// -------------------------------------------------------------


// Funci�n que trata un caso de prueba.
bool tratar_caso() {
    Restaurante r;

    string operacion;
    cin >> operacion;

    if (cin.eof()) return false;

    while (operacion != "FIN") {
        try {
            if (operacion == "nueva_mesa") {
                int n; cin >> n;
                r.nueva_mesa(n);
            }
            else if (operacion == "nuevo_pedido") {
                int n; cin >> n;
                string p; cin >> p;
                r.nuevo_pedido(n, p);
            }
            else if (operacion == "cancelar_pedido") {
                int n; cin >> n;
                string p; cin >> p;
                r.cancelar_pedido(n, p);
            }
            else if (operacion == "servir") {
                pair<int, string> par = r.servir();
                cout << par.second << " " << par.first << "\n";
            }
            else if (operacion == "que_falta") {
                int n; cin >> n;
                vector<string> platos = r.que_falta(n);
                cout << "En la mesa " << n << " falta:\n";
                for (const string& p : platos) {
                    cout << "  " << p << "\n";
                }
            }
        }
        catch (exception& e) {
            cout << "ERROR: " << e.what() << "\n";
        }

        cin >> operacion;
    }

    cout << "---\n";

    return true;
} // tratar_caso

int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (tratar_caso()) {}

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif

    return 0;
}