// Escamochar una lista
// --------------------
// Estructuras de datos

#include <iostream>
#include <cassert>
#include <fstream>
#include <vector>

using namespace std;

class ListLinkedSingle {
private:
    struct Node {
        int value;
        Node* next;
    };

public:
    ListLinkedSingle() : head(nullptr) { }
    ~ListLinkedSingle() {
        delete_list(head);
    }

    ListLinkedSingle(const ListLinkedSingle& other)
        : head(copy_nodes(other.head)) { }

    void push_front(int elem) {
        Node* new_node = new Node{ elem, head };
        head = new_node;
    }

    void push_back(int elem);

    void pop_front() {
        assert(head != nullptr);
        Node* old_head = head;
        head = head->next;
        delete old_head;
    }

    void pop_back();

    int size() const;

    bool empty() const {
        return head == nullptr;
    };

    const int& front() const {
        assert(head != nullptr);
        return head->value;
    }

    int& front() {
        assert(head != nullptr);
        return head->value;
    }

    const int& back() const {
        return last_node()->value;
    }

    int& back() {
        return last_node()->value;
    }

    const int& at(int index) const {
        Node* result_node = nth_node(index);
        assert(result_node != nullptr);
        return result_node->value;
    }

    int& at(int index) {
        Node* result_node = nth_node(index);
        assert(result_node != nullptr);
        return result_node->value;
    }


    void display(std::ostream& out) const;
    void display() const {
        display(std::cout);
    }

    // Declaraci�n del m�todo. Implem�ntalo antes de la
    // funci�n tratar_caso()
    void escamochar(ListLinkedSingle& dest);

private:
    Node* head;

    void delete_list(Node* start_node);
    Node* last_node() const;
    Node* nth_node(int n) const;
    Node* copy_nodes(Node* start_node) const;

};

ListLinkedSingle::Node* ListLinkedSingle::copy_nodes(Node* start_node) const {
    if (start_node != nullptr) {
        Node* result = new Node{ start_node->value, copy_nodes(start_node->next) };
        return result;
    }
    else {
        return nullptr;
    }
}

void ListLinkedSingle::delete_list(Node* start_node) {
    if (start_node != nullptr) {
        delete_list(start_node->next);
        delete start_node;
    }
}

void ListLinkedSingle::push_back(int elem) {
    Node* new_node = new Node{ elem, nullptr };
    if (head == nullptr) {
        head = new_node;
    }
    else {
        last_node()->next = new_node;
    }
}

void ListLinkedSingle::pop_back() {
    assert(head != nullptr);
    if (head->next == nullptr) {
        delete head;
        head = nullptr;
    }
    else {
        Node* previous = head;
        Node* current = head->next;

        while (current->next != nullptr) {
            previous = current;
            current = current->next;
        }

        delete current;
        previous->next = nullptr;
    }
}

int ListLinkedSingle::size() const {
    int num_nodes = 0;

    Node* current = head;
    while (current != nullptr) {
        num_nodes++;
        current = current->next;
    }

    return num_nodes;
}


ListLinkedSingle::Node* ListLinkedSingle::last_node() const {
    assert(head != nullptr);
    Node* current = head;
    while (current->next != nullptr) {
        current = current->next;
    }
    return current;
}

ListLinkedSingle::Node* ListLinkedSingle::nth_node(int n) const {
    assert(0 <= n);
    int current_index = 0;
    Node* current = head;

    while (current_index < n && current != nullptr) {
        current_index++;
        current = current->next;
    }

    return current;
}

void ListLinkedSingle::display(std::ostream& out) const {
    out << "[";
    if (head != nullptr) {
        out << head->value;
        Node* current = head->next;
        while (current != nullptr) {
            out << ", " << current->value;
            current = current->next;
        }
    }
    out << "]";
}

//---------------------------------------------------------------
// Modificar a partir de aqu�
// --------------------------------------------------------------


// �No olvides indicar el coste del m�todo!
void ListLinkedSingle::escamochar(ListLinkedSingle& dest) {
    
    Node* current = this->head;
    Node* previous = nullptr;

    //Tenemos que buscar el primer nodo que tenga un n�mero positivo

    while (current !=nullptr && current->value <0)
    {
        previous = current;
        current = current->next;
    }

    //Current ahora mismo apuntar�a al primer n�mero no negativo de la cadena.
    //Prev apuntar�a a la �ltima letra negativa. O a nullptr

    if (previous != nullptr)
    {
        dest.head = this->head;
        this->head = current;
    }

    //Ahora tenemos que buscar el �ltimo n�mero positivo

    Node* last_positive = nullptr;

    while (current != nullptr)
    {
        if (current->value >= 0)
        {
            last_positive = current;
        }
        current = current->next;
    }

    //En este punto last_positive tiene el �ltimo positivo o nullptr 

    Node* rest = nullptr;

    if (last_positive != nullptr)
    {
        rest = last_positive->next;
        last_positive->next = nullptr;
    }

    if (previous!=nullptr)
    {
        previous->next = rest;
    }

    else
    {
        dest.head = rest;
    }

}


void tratar_caso() {
    
    int n; //Numero de n�meros de nuestra lista 
    ListLinkedSingle ls;//Inicializa head a nullptr.

    cin >> n;

    vector<int> numeros(n);

    for (int i = 0; i < n; i++)//Coste lineal en el n�mero de elementos n. O(n)
    {
        cin >> numeros[i];
        ls.push_front(numeros[i]); //Coste constante en el peor de los casos
    }

    ListLinkedSingle ms;

    ls.escamochar(ms);

    ls.display();
    cout << endl;
    ms.display();
    cout << endl;
}



int main() {
    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
 // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
 // �til para no tener que teclear los casos de prueba por teclado cada vez
 // que ejecutas el programa.
 //
 // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
 // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // La entrada comienza con el n�mero de casos de prueba.
    int num_casos;
    cin >> num_casos;

    // Llamamos tantas veces a `tratar_caso` como nos diga el n�mero.
    for (int i = 0; i < num_casos; i++) {
        tratar_caso();
    }

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
