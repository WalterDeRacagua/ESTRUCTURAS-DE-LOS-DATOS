// Referencias cruzadas
// --------------------
// Estructuras de datos


// Utiliza las clases de la STL de C++ para este problema
// A�ade los #include que creas necesarios

#include <iostream>
#include <cassert>
#include<fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cctype>
#include <map>
#include<set>

using namespace std;


// 
// Implementa a continuaci�n la funci�n que trata un caso de prueba.
// Devuelve false si, en lugar de un caso de prueba, se encuentra la marca
// de fin de la entrada (0), o true en caso contrario.
//

void minusculas(string& palabra) {

    for (char& c : palabra) {
        c = tolower(c);
    }
}

bool tratar_caso() {
	
    int num_lineas;
    string linea;
    string palabra;
    

    cin >> num_lineas;

    cin.ignore();

    if (num_lineas ==0)
    {
        return false;
    }

    map<string, set<int>> diccionario; 

    for (int i = 0; i < num_lineas; i++)
    {
        getline(cin, linea);

        stringstream ss(linea);

        while (ss>> palabra)
        {
            if (palabra.length()>2)
            {
                minusculas(palabra);
             
                diccionario[palabra].insert(i+1);//O(log(M) siendo M el numero de palabras del diccionario 
            }
        }
    }

    for (auto[k,v]:diccionario)
    {
        cout << k << " ";

        for (auto it  = v.begin(); it != v.end(); ++it)
        {
            cout << *it << " ";
        }

        cout << "\n";

    }

    cout << "---"<<endl;


    return true;
}


int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // La entrada comienza con el n�mero de casos de prueba.

    // Llamamos a `tratar_caso` tantas veces como el n�mero anterior.
    while (tratar_caso())
    {

    }

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
