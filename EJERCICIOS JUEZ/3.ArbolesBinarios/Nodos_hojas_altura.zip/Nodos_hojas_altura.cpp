// N�mero de nodos, hojas y altura de un �rbol binario
// ---------------------------------------------------
// Estructuras de datos


#include <iostream>
#include <fstream>
#include <cassert>
#include <memory>

using namespace std;

// TAD de �rboles binarios de b�squeda
template <class T> class BinTree {
public:
    BinTree() : root_node(nullptr) {}

    BinTree(const T& elem)
        : root_node(std::make_shared<TreeNode>(nullptr, elem, nullptr)) {}

    BinTree(const BinTree& left, const T& elem, const BinTree& right)
        : root_node(std::make_shared<TreeNode>(left.root_node, elem,
            right.root_node)) {}

    bool empty() const { return root_node == nullptr; }

    const T& root() const {
        assert(root_node != nullptr);
        return root_node->elem;
    }

    BinTree left() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->left;
        return result;
    }

    BinTree right() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->right;
        return result;
    }

    void display(std::ostream& out) const { display_node(root_node, out); }

private:
    // Las definiciones de TreeNode y NodePointer dependen recursivamente
    // la una de la otra. Por eso declaro 'struct TreeNode;' antes de NodePointer
    // para que el compilador sepa, cuando analice la definici�n de NodePointer,
    // que TreeNode va a ser definida m�s adelante.

    struct TreeNode;
    using NodePointer = std::shared_ptr<TreeNode>;

    struct TreeNode {
        TreeNode(const NodePointer& left, const T& elem, const NodePointer& right)
            : elem(elem), left(left), right(right) {}

        T elem;
        NodePointer left, right;
    };

    NodePointer root_node;

    static void display_node(const NodePointer& root, std::ostream& out) {
        if (root == nullptr) {
            out << ".";
        }
        else {
            out << "(";
            display_node(root->left, out);
            out << " " << root->elem << " ";
            display_node(root->right, out);
            out << ")";
        }
    }
};

template <typename T>
std::ostream& operator<<(std::ostream& out, const BinTree<T>& tree) {
    tree.display(out);
    return out;
}

template <typename T> BinTree<T> read_tree(std::istream& in) {
    char c;
    in >> c;
    if (c == '.') {
        return BinTree<T>();
    }
    else {
        assert(c == '(');
        BinTree<T> left = read_tree<T>(in);
        T elem;
        in >> elem;
        BinTree<T> right = read_tree<T>(in);
        in >> c;
        assert(c == ')');
        BinTree<T> result(left, elem, right);
        return result;
    }
}

using namespace std;



// Implementa las funciones recursivas que sean necesarias.
/*
Inicialmente hab�a pensado en que devolviera un par que dijera si es equilibrado y su altura.
Pero voy a usar mejor una tupla que diga si es equilibrado, si es raquitico y su altura
*/

/*
El primer par�metro es el n�mero de nodos.

El segundo par�metro es el n�mero de hojas.

El tercer par�metro es la altura del �rbol.

*/
template <typename T>
tuple<int, int, int>altura_hojas_nodos(const BinTree<T>& tree) {

    if (tree.empty())
    {
        return { 0,0,0 };
    }
    else if (!tree.empty() &&tree.left().empty() && tree.right().empty())
    {
        return{ 1,1 ,1};
    }
    else
    {
        
        auto [nodos_izquierda, hojas_izquierda, altura_izquierda] = altura_hojas_nodos(tree.left());
        auto [nodos_derecha, hojas_derecha, altura_derecha] = altura_hojas_nodos(tree.right());

        int num_nodos = 1 + nodos_izquierda+nodos_derecha;
        int num_hojas = hojas_derecha + hojas_izquierda;

        int altura = 1 + max(altura_izquierda, altura_derecha);

        return { num_nodos,num_hojas,altura };
    }
}


/*
COSTE Y RECURRENCIA:

RECORDATORIO:

El primer par�metro de la funci�n es para saber el n�mero de nodos; el segundo par�metro es para saber el n�mero de hojas
y el tercero es para saber la altura del �rbol.

Todo lo hemos realizado en una sola funci�n para no tener problemas en el coste de la funci�n. As� que la recurrencia del 
problema es de la siguiente forma:

Para definir la recurrencia y el coste primero resalto que lo voy a definir sobre un n�mero "n" siendo n el n�mero de nodos
del �rbol. La recurrencia es de la siguiente forma:


            {k0         si n =0 o n=1; Constante ya que solo se hacen asignaciones
    T(n)=
            {T(ni) + T(nd) +k1 si n>1;

    Por tanto, sabiendo la forma de la recurrencia deduzco que el coste de mi algoritmo es T(n)=n;


*/



void tratar_caso() {
    // Introduce aqu� el c�digo para tratar un caso de prueba.

    BinTree<char> t = read_tree<char>(cin);
    auto [num_nodos, num_hojas, altura] = altura_hojas_nodos(t);

    cout << num_nodos << " " << num_hojas << " " << altura << endl;
}


int main() {
    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
    // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
    // �til para no tener que teclear los casos de prueba por teclado cada vez
    // que ejecutas el programa.
    //
    // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
    // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // La entrada comienza con el n�mero de casos de prueba.
    int num_casos;
    cin >> num_casos;

    // Llamamos a `tratar_caso` tantas veces como el n�mero anterior.
    for (int i = 0; i < num_casos; i++) {
        tratar_caso();
    }

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}


