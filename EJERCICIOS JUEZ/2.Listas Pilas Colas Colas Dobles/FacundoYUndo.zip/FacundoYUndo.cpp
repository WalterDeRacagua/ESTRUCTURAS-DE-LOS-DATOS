// Facundo y el undo
// -----------------
// Estructuras de datos


/*
  En este ejercicio solamente pueden utilizarse las colecciones vistas durante
  esta semana: pilas, colas, o dobles colas.

  En lugar de utilizar las implementaciones vistas en clase, utilizad las que
  vienen implementadas en la biblioteca est�ndar de C++, que son las
  siguientes:

  - queue, definida en el fichero de cabecera <queue>
    Documentaci�n: https://en.cppreference.com/w/cpp/container/queue

  - stack, definida en el fichero de cabecera <stack>
    Documentaci�n: https://en.cppreference.com/w/cpp/container/stack

  - deque, definida en el fichero de cabecera <deque>
    Documentaci�n: https://en.cppreference.com/w/cpp/container/deque

  A�ade los #include con los ficheros de cabecera del TAD o los TADs que
  vais a utilizar.
*/


#include <iostream>
#include <cassert>
#include <string> 
#include <fstream>
#include <sstream>
#include <stack>
#include <deque>


using namespace std;



// Implementa aqu� la funci�n para tratar UN caso de prueba. 

// No olvides indicar y justificar el coste de la funci�n.

void tratar_caso() {

    deque<string> resultado;
    stack<string> borrados;
    stack<string> operaciones;

    string oracion_entera;
    string palabra;

    getline(cin, oracion_entera);
    istringstream lector_palabras(oracion_entera);

    while (lector_palabras >> palabra) {
        if (palabra != "+" && palabra != "*") {
            // Se introduce una nueva palabra
            resultado.push_back(palabra);
            operaciones.push("push");
        }
        else if (palabra == "*") {
            // Se elimina la �ltima palabra
            if (!resultado.empty()) {
                string borrado = resultado.back();
                borrados.push(borrado);
                resultado.pop_back();
                operaciones.push("*");
            }
        }
        else if (palabra == "+") {
            // Se deshace la �ltima operaci�n
            if (!operaciones.empty()) {
                string ultima_operacion = operaciones.top();
                operaciones.pop();
                if (ultima_operacion == "push") {
                    if (!resultado.empty()) {
                        resultado.pop_back();
                    }
                }
                else if (ultima_operacion == "*") {
                    if (!borrados.empty()) {
                        string ultimo_borrado = borrados.top();
                        borrados.pop();
                        resultado.push_back(ultimo_borrado);
                    }
                }
            }
        }
    }

    // Mostrar el resultado final
    while (!resultado.empty()) {
        cout << resultado.front() << " ";
        resultado.pop_front();
    }
    cout << endl;



}

int main() {
#ifndef DOMJUDGE
    ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
    int num_casos;
    cin >> num_casos;
    cin.ignore(10, '\n');

    // Ejecutamos tratar_caso() tantas veces como diga el n�mero le�do
    for (int i = 0; i < num_casos; i++) {
        tratar_caso();
    }



#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;

} // main