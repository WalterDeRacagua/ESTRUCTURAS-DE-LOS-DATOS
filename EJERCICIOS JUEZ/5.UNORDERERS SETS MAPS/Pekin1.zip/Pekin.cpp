// Misterios de Pek�n
// ------------------
// Estructuras de datos

// A�ade los #include que creas necesarios

#include <iostream>
#include <fstream>
#include <vector>
#include<unordered_set>
#include<unordered_map>
#include <map>
#include<set>


using namespace std;


class MisteriosDePekin {
public:
    MisteriosDePekin(const string& culpable) {//O(1)
        this->culpable = culpable;
        this->sospechosos_rasgos[culpable];
        this->todos_los_culpables.insert(culpable);
    }

    void anyadir_rasgo(const string& sospechoso, const string& rasgo) {//O(log(M)) siendo M el numero de sospehosos anyadidos

        if (!this->jugador_descartados.empty())
        {
            throw domain_error("Juego ya empezado");
        }

        this->sospechosos_rasgos[sospechoso].insert(rasgo);//O(log(M)) 
        this->rasgos_sospechosos[rasgo].insert(sospechoso);//O(1) ambos son unordered
        this->todos_los_culpables.insert(sospechoso);


    }

    vector<string> sospechosos() const {//Coste lineal en el n�mero de sospechosos. O(S)

        vector<string> s;

        for (auto sos: this->sospechosos_rasgos)
        {
            s.push_back(sos.first);//O(1)
        }


        return s;
    }

    void nuevo_jugador(const string& nombre) {//O(1)

        if (this->jugador_descartados.count(nombre))//O(1)
        {
            throw domain_error("Jugador existente");
        }

        this->jugador_descartados[nombre];//O(1)

    }

    void jugador_descarta(const string& jugador, const string& rasgo) {//Lineal en el numero de personas que tienen el rasgo "rasgo"

        if (!this->jugador_descartados.count(jugador))//O(1)
        {
            throw domain_error("Jugador no existente");
        }

        for (auto r: this->rasgos_sospechosos[rasgo])//Lineal en el numero de personas que tienen ese rasgo
        {
            this->jugador_descartados[jugador].insert(r); //O(1)
        }
    }

    bool jugador_enganyado(const string& jugador) const {

        if (!this->jugador_descartados.count(jugador))
        {
            throw domain_error("Jugador no existente");
        }

        auto it= this->jugador_descartados.at(jugador).find(this->culpable);

        if (it == this->jugador_descartados.at(jugador).end())
        {
            return false;
        }

        return true;
    }

    bool puede_detener_culpable(const string& jugador) const {

        if (!this->jugador_descartados.count(jugador))
        {
            throw domain_error("Jugador no existente");
        }

        if (this->jugador_descartados.at(jugador).size()!= this->todos_los_culpables.size()-1)
        {
            return false;
        }

        auto it = this->jugador_descartados.at(jugador).find(this->culpable);

        if (it == this->jugador_descartados.at(jugador).end())
        {
            return true;
        }

        return false;
    }


private:
    
    string culpable;
    map<string, unordered_set<string>> sospechosos_rasgos;
    unordered_map<string, unordered_set<string>> rasgos_sospechosos;
    unordered_map<string, unordered_set<string>> jugador_descartados;
    unordered_set<string> todos_los_culpables;
};


bool tratar_caso() {
    string culpable;
    cin >> culpable;

    if (cin.eof()) return false;

    MisteriosDePekin mp(culpable);
    cout << "OK" << endl;

    string comando;
    cin >> comando;

    while (comando != "FIN") {
        try {
            if (comando == "anyadir_rasgo") {
                string sospechoso, rasgo;
                cin >> sospechoso >> rasgo;
                mp.anyadir_rasgo(sospechoso, rasgo);
                cout << "OK" << endl;
            }
            else if (comando == "sospechosos") {
                bool primero = true;
                for (const string& s : mp.sospechosos()) {
                    cout << (primero ? "" : " ") << s;
                    primero = false;
                }
                cout << endl;
            }
            else if (comando == "nuevo_jugador") {
                string nombre;
                cin >> nombre;
                mp.nuevo_jugador(nombre);
                cout << "OK" << endl;
            }
            else if (comando == "jugador_descarta") {
                string nombre; string rasgo;
                cin >> nombre >> rasgo;
                mp.jugador_descarta(nombre, rasgo);
                cout << "OK" << endl;
            }
            else if (comando == "jugador_enganyado") {
                string nombre;
                cin >> nombre;
                bool enganyado = mp.jugador_enganyado(nombre);
                cout << nombre << (enganyado ? "" : " no") << " ha sido enganyado" << endl;
            }
            else if (comando == "puede_detener_culpable") {
                string nombre;
                cin >> nombre;
                bool puede = mp.puede_detener_culpable(nombre);
                cout << nombre << (puede ? "" : " no") << " puede detener al culpable" << endl;
            }
        }
        catch (exception& e) {
            cout << "ERROR: " << e.what() << endl;
        }

        cin >> comando;
    }

    cout << "---" << endl;

    return true;
}

int main() {
#ifndef DOMJUDGE
    ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (tratar_caso())
        ;

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif


    return 0;

} // main