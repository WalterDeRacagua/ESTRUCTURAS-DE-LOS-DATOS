// Elemento m�nimo de un �rbol
// ---------------------------
// Estructuras de datos


#include <iostream>
#include <fstream>
#include <cassert>
#include <memory>


// TAD de �rboles binarios de b�squeda
template <class T> class BinTree {
public:
    BinTree() : root_node(nullptr) {}

    BinTree(const T& elem)
        : root_node(std::make_shared<TreeNode>(nullptr, elem, nullptr)) {}

    BinTree(const BinTree& left, const T& elem, const BinTree& right)
        : root_node(std::make_shared<TreeNode>(left.root_node, elem,
            right.root_node)) {}

    bool empty() const { return root_node == nullptr; }

    const T& root() const {
        assert(root_node != nullptr);
        return root_node->elem;
    }

    BinTree left() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->left;
        return result;
    }

    BinTree right() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->right;
        return result;
    }

    void display(std::ostream& out) const { display_node(root_node, out); }

private:
    // Las definiciones de TreeNode y NodePointer dependen recursivamente
    // la una de la otra. Por eso declaro 'struct TreeNode;' antes de NodePointer
    // para que el compilador sepa, cuando analice la definici�n de NodePointer,
    // que TreeNode va a ser definida m�s adelante.

    struct TreeNode;
    using NodePointer = std::shared_ptr<TreeNode>;

    struct TreeNode {
        TreeNode(const NodePointer& left, const T& elem, const NodePointer& right)
            : elem(elem), left(left), right(right) {}

        T elem;
        NodePointer left, right;
    };

    NodePointer root_node;

    static void display_node(const NodePointer& root, std::ostream& out) {
        if (root == nullptr) {
            out << ".";
        }
        else {
            out << "(";
            display_node(root->left, out);
            out << " " << root->elem << " ";
            display_node(root->right, out);
            out << ")";
        }
    }
};

template <typename T>
std::ostream& operator<<(std::ostream& out, const BinTree<T>& tree) {
    tree.display(out);
    return out;
}

template <typename T> BinTree<T> read_tree(std::istream& in) {
    char c;
    in >> c;
    if (c == '.') {
        return BinTree<T>();
    }
    else {
        assert(c == '(');
        BinTree<T> left = read_tree<T>(in);
        T elem;
        in >> elem;
        BinTree<T> right = read_tree<T>(in);
        in >> c;
        assert(c == ')');
        BinTree<T> result(left, elem, right);
        return result;
    }
}

using namespace std;



template <typename T>
T minimo(const BinTree<T>& arbol) {

    assert(!arbol.empty()); // Aseg�rate de que el �rbol no est� vac�o

    T min_elem = arbol.root();

    if (!arbol.left().empty()) {

        min_elem = std::min(min_elem, minimo(arbol.left()));

    }

    if (!arbol.right().empty()) {

        min_elem = std::min(min_elem, minimo(arbol.right()));

    }

    return min_elem;

}


/*
COSTE Y RECURRENCIA DE MI �RBOL

�La funci�n m�nimo devuelve un T que en este caso  puede ser un entero o una cadena.
En este caso voy a definir el coste sobre el n�mero de nodos del �rbol binario "n".

        {k0 si n=1;
    T(n)=
        {T(ni) +T(nd)+ k1 si n>1;

        ni son los nodos del sub�rbol izquierdo y nd los del sub�rbol derecho.

        Teniendo en cuenta la recurrencia el coste es T(n) = O(n) lineal en el n�emro de nodos.

*/


bool tratar_caso() {
    // Introduce aqu� el c�digo para tratar un caso de prueba. Devuelve true si
    // se ha encontrado un caso de prueba, o false si se ha encontrado con el
    // fin de fichero.

    char tipo;

 

    cin >> tipo;

    if (!cin)
    {
        return false;
    }

    if (tipo == 'N')
    {
        BinTree<int> tN = read_tree<int>(cin);
        cout << minimo(tN)<< endl;

    }
    else
    {
        BinTree<string> tP = read_tree<string>(cin);
        cout << minimo(tP) << endl;

    }


    // Tendr�s que utilizar read_tree<string> o read_tree<int> en funci�n de si la primera l�nea
    // leida es N o P.

    return true;
}


int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (tratar_caso()) {}

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    // Descomentar si se trabaja en Windows
    // system("PAUSE");
#endif
    return 0;
}
