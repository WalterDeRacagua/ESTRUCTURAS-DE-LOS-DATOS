// �rea m�s grande en un �rbol binario
// -----------------------------------
// Estructuras de datos


#include <iostream>
#include <cassert>
#include <memory>
#include <utility>
#include <fstream>
#include <algorithm>

// TAD de �rboles binarios de b�squeda
template <class T> class BinTree {
public:
    BinTree() : root_node(nullptr) {}

    BinTree(const T& elem)
        : root_node(std::make_shared<TreeNode>(nullptr, elem, nullptr)) {}

    BinTree(const BinTree& left, const T& elem, const BinTree& right)
        : root_node(std::make_shared<TreeNode>(left.root_node, elem,
            right.root_node)) {}

    bool empty() const { return root_node == nullptr; }

    const T& root() const {
        assert(root_node != nullptr);
        return root_node->elem;
    }

    BinTree left() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->left;
        return result;
    }

    BinTree right() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->right;
        return result;
    }

    void display(std::ostream& out) const { display_node(root_node, out); }

private:
    // Las definiciones de TreeNode y NodePointer dependen recursivamente
    // la una de la otra. Por eso declaro 'struct TreeNode;' antes de NodePointer
    // para que el compilador sepa, cuando analice la definici�n de NodePointer,
    // que TreeNode va a ser definida m�s adelante.

    struct TreeNode;
    using NodePointer = std::shared_ptr<TreeNode>;

    struct TreeNode {
        TreeNode(const NodePointer& left, const T& elem, const NodePointer& right)
            : elem(elem), left(left), right(right) {}

        T elem;
        NodePointer left, right;
    };

    NodePointer root_node;

    static void display_node(const NodePointer& root, std::ostream& out) {
        if (root == nullptr) {
            out << ".";
        }
        else {
            out << "(";
            display_node(root->left, out);
            out << " " << root->elem << " ";
            display_node(root->right, out);
            out << ")";
        }
    }
};

template <typename T>
std::ostream& operator<<(std::ostream& out, const BinTree<T>& tree) {
    tree.display(out);
    return out;
}

template <typename T> BinTree<T> read_tree(std::istream& in) {
    char c;
    in >> c;
    if (c == '.') {
        return BinTree<T>();
    }
    else {
        assert(c == '(');
        BinTree<T> left = read_tree<T>(in);
        T elem;
        in >> elem;
        BinTree<T> right = read_tree<T>(in);
        in >> c;
        assert(c == ')');
        BinTree<T> result(left, elem, right);
        return result;
    }
}

using namespace std;

/*
El primer valor es para devolver el area acumulada 
El segundo valor es para devolver el area maxima

*/
pair<int,int> area_mayor_sin_barreras(const BinTree<bool>& tree) {
    
    if (tree.empty())
    {
        return { 0,0 };
    }
    else
    {

        auto[area_izquierda,maximo_izquierda]= area_mayor_sin_barreras(tree.left());
        auto[area_derecha,maximo_derecha]= area_mayor_sin_barreras(tree.right());

        if (tree.root()==false)
        {
            return { 1 + area_izquierda + area_derecha,  max(1 + area_izquierda + area_derecha,max(maximo_izquierda,maximo_derecha))};
        }
        else
        {
            return { 0, max(maximo_izquierda,maximo_derecha) };
        }
    }

}


/*
COSTE Y RECURRENCIA DEL �RBOL BINARIO

Lo voy a definir sobre un n�mero n, siendo n el n�mero de nodos. Entonces tenemos:

        {k0                         si n=0;
    T(n)
        {T(ni)+ T(nd) +k1           si n>0;

    Por tanto el coste de mi algoritmo es lineal respecto al n�mero de nodos del �rbol.
    Si hubiera hecho esta funci�n en dos funciones, para calcular cada dato
    de manera individual (maximo y area acumulada), el coste de mi algoritmo ser�a cuadr�tico


*/


// Funci�n que trata un caso de prueba
void tratar_caso() {
    BinTree<bool> t = read_tree<bool>(cin);

    auto [areas, maximo] = area_mayor_sin_barreras(t);

    cout << maximo << "\n";
}


int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    int numCasos;

    cin >> numCasos;

    for (int i = 0; i < numCasos; i++)
    {
        tratar_caso();
    }

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    // Descomentar si se trabaja en Windows
    // system("PAUSE");
#endif
    return 0;
}