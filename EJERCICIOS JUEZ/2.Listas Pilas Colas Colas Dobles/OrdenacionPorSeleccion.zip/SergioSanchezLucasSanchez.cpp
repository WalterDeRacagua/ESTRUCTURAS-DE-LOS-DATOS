/*
 * ---------------------------------------------------
 *                ESTRUCTURAS DE DATOS
 * ---------------------------------------------------
 *              Facultad de Inform�tica
 *         Universidad Complutense de Madrid
 * ---------------------------------------------------
 */

 /*
  * MUY IMPORTANTE: Para realizar este ejercicio solo pod�is
  * modificar el c�digo contenido entre las etiquetas <answer>
  * y </answer>. Toda modificaci�n fuera de esas etiquetas est�
  * prohibida, pues no se tendr� en cuenta para la correcci�n.
  *
  * Tampoco esta permitido modificar las l�neas que contienen
  * las etiquetas <answer> y </answer>, obviamente :-)
  */


  //@ <answer>
  /*
    Indica el nombre y apellidos de los componentes del grupo
    ---------------------------------------------------------
    Componente 1: Sergio S�nchez Carrasco
    Componente 2: Lucas S�nchez Mart�n
  */
  //@ </answer>

#include <iostream>
#include <vector>
#include<cmath>
#include <fstream>
#include <cassert>
#include <string> 


/*
  Implementaci�n de listas doblemente enlazadas circulares

  https://github.com/manuelmontenegro/ED/blob/main/lineales/list_linked_double_v4/list_linked_double.h

*/

class ListLinkedDouble {
private:
    struct Node {
        int value;
        Node* next;
        Node* prev;
    };

public:
    ListLinkedDouble() : num_elems(0) {
        head = new Node;
        head->next = head;
        head->prev = head;
    }

    ListLinkedDouble(const ListLinkedDouble& other) : ListLinkedDouble() {
        copy_nodes_from(other);
        num_elems = other.num_elems;
    }

    ~ListLinkedDouble() { delete_nodes(); }

    void push_front(const int& elem) {
        Node* new_node = new Node{ elem, head->next, head };
        head->next->prev = new_node;
        head->next = new_node;
        num_elems++;
    }

    void push_back(const int& elem) {
        Node* new_node = new Node{ elem, head, head->prev };
        head->prev->next = new_node;
        head->prev = new_node;
        num_elems++;
    }

    void pop_front() {
        assert(num_elems > 0);
        Node* target = head->next;
        head->next = target->next;
        target->next->prev = head;
        delete target;
        num_elems--;
    }

    void pop_back() {
        assert(num_elems > 0);
        Node* target = head->prev;
        target->prev->next = head;
        head->prev = target->prev;
        delete target;
        num_elems--;
    }

    int size() const { return num_elems; }

    bool empty() const { return num_elems == 0; };

    const int& front() const {
        assert(num_elems > 0);
        return head->next->value;
    }

    int& front() {
        assert(num_elems > 0);
        return head->next->value;
    }

    const int& back() const {
        assert(num_elems > 0);
        return head->prev->value;
    }

    int& back() {
        assert(num_elems > 0);
        return head->prev->value;
    }

    const int& operator[](int index) const {
        assert(0 <= index && index < num_elems);
        Node* result_node = nth_node(index);
        return result_node->value;
    }

    int& operator[](int index) {
        assert(0 <= index && index < num_elems);
        Node* result_node = nth_node(index);
        return result_node->value;
    }

    ListLinkedDouble& operator=(const ListLinkedDouble& other) {
        if (this != &other) {
            delete_nodes();
            head = new Node;
            head->next = head->prev = head;
            copy_nodes_from(other);
            num_elems = other.num_elems;
        }
        return *this;
    }

    void display(std::ostream& out) const;

    void display() const { display(std::cout); }

    // Implementa este m�todo m�s abajo
    void sort_and_dedup();

private:
    Node* head;
    int num_elems;

    Node* nth_node(int n) const;
    void delete_nodes();
    void copy_nodes_from(const ListLinkedDouble& other);

    // M�todos privados. Implem�ntalos m�s abajo
    Node* minimum(Node* begin, Node* end) const;
    void detach(Node* n);
    void attach(Node* n, Node* position);
};

ListLinkedDouble::Node* ListLinkedDouble::nth_node(int n) const {
    int current_index = 0;
    Node* current = head->next;

    while (current_index < n && current != head) {
        current_index++;
        current = current->next;
    }

    return current;
}

void ListLinkedDouble::delete_nodes() {
    Node* current = head->next;
    while (current != head) {
        Node* target = current;
        current = current->next;
        delete target;
    }

    delete head;
}

void ListLinkedDouble::copy_nodes_from(const ListLinkedDouble& other) {
    Node* current_other = other.head->next;
    Node* last = head;

    while (current_other != other.head) {
        Node* new_node = new Node{ current_other->value, head, last };
        last->next = new_node;
        last = new_node;
        current_other = current_other->next;
    }
    head->prev = last;
}

void ListLinkedDouble::display(std::ostream& out) const {
    out << "[";
    if (head->next != head) {
        out << head->next->value;
        Node* current = head->next->next;
        while (current != head) {
            out << ", " << current->value;
            current = current->next;
        }
    }
    out << "]";
}

std::ostream& operator<<(std::ostream& out, const ListLinkedDouble& l) {
    l.display(out);
    return out;
}

//@ <answer>
//---------------------------------------------------------------
// Modificar a partir de aqu�
// --------------------------------------------------------------

ListLinkedDouble::Node* ListLinkedDouble::minimum(Node* begin, Node* end) const {
    
    Node* current = begin;
    Node* mini = begin;//Se apunta a si mismo

    while (current != end)//Podemos suponer que no son iguales
    {
        if (mini->value > current->value)
        {
            mini = current;
        }

        current = current->next;
    }

    return mini;
}

void ListLinkedDouble::detach(Node* n) {
    //Esta funci�n tiene COSTE constante en el n�mero de elementos de la List. Simplemente hacemos asignaciones a los nodos. Luego O(1).
    
    n->next->prev = n->prev;
    n->prev->next = n->next;
    
    //NO ES NECESARIO QUE ESTRICTAMENTE SE APUNTE A S� MISMO (CREO), PERO ME SIRVE A MI PARA VER MEJOR EL FLUJO DE EJECUCI�N
    n->prev = n;
    n->next = n; //Hago que se apunte a si mismo.
    //el numero de elementos no disminuye porque lo hacemos sobre la misma lista.

}

void ListLinkedDouble::attach(Node* n, Node* position) {//Lo sit�a despu�s del nodo apuntado position
   
    //El COSTE de esta funci�n es constante en el n�mero de elementos de la List, ya que �nicamente se hacen asignaciones y la eliminaci�n de un nodo. Luego O(1)

    if (n->value != position->value)
    {  
        n->next = position->next;
        n->prev = position;
        position->next->prev = n;
        position->next = n;
    }
    else //Creo que podr�amos hacer esto en el m�todo sort_and_dedup(), pero no creo que est� mal.
    {
        delete n;
    }
}

void ListLinkedDouble::sort_and_dedup() {
    
    Node* current = this->head->next;

        while (current != this->head) //No es necesario hacer attach(), el ejercicio no te pide 
        {
            Node* minNode = minimum(current, head);
            /*INTERCAMBIAMOS VALORES*/
            int aux = current->value;
            current->value = minNode->value;
            minNode->value = aux;

            current = current->next;
        }

        current = this->head->next;

        while (current->next != head)
        {
            if (current->value ==current->next->value)
            {
                Node* temp = current->next;
                this->detach(temp);
                delete temp;
            }
            else
            {
                current = current->next;
            }
        }

    /*
    El coste de esta funci�n es lineal en el n�mero de elementos de la lista ListLinkedDouble porque 
    recorremos 1 vez dos bucles NO anidados, ambos de coste lineal. Por tanto, el coste de este m�todo
    es el m�ximo de entre los dos bucles. Como el coste de ambos bucles es lineal en el n�mero de elementos
    (vamos a suponer que el n�mero de elementos es "m")de la lista, el coste del m�todo es O(m).
    
    */

}

using namespace std;

// Implementa aqu� la funci�n para tratar UN caso de prueba. La funci�n `main`
// llamar� a esta funci�n `tratar_caso` tantas veces como casos de prueba hay
// en la entrada.

void tratar_caso() {
    
    ListLinkedDouble xs;

    int n = 0;

    cin >> n;

    while (n != -1)//Coste lineal en el n�mero de numeros de la lista.
    {
        xs.push_back(n);//Coste constante, solo se hacen 
                        //asignaciones en las listas doblemente enlazadas circulares

        cin >> n;
    }

    xs.sort_and_dedup();
    
    xs.display();
    cout << "\n";

}

//---------------------------------------------------------------
// No modificar por debajo de esta l�nea
// --------------------------------------------------------------
//@ </answer>


int main() {

    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
    // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
    // �til para no tener que teclear los casos de prueba por teclado cada vez
    // que ejecutas el programa.
    //
    // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
    // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // La entrada comienza con el n�mero de casos de prueba.
    int num_casos;
    cin >> num_casos;

    // Llamamos tantas veces a `tratar_caso` como nos diga el n�mero.
    for (int i = 0; i < num_casos; i++) {
        tratar_caso();
    }

    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
