// Excursionistas atrapados
// ------------------------
// Estructuras de datos


#include <iostream>
#include <cassert>
#include <memory>
#include <utility>
#include <cmath>
#include <fstream>

// TAD de �rboles binarios de b�squeda
template <class T> class BinTree {
public:
    BinTree() : root_node(nullptr) {}

    BinTree(const T& elem)
        : root_node(std::make_shared<TreeNode>(nullptr, elem, nullptr)) {}

    BinTree(const BinTree& left, const T& elem, const BinTree& right)
        : root_node(std::make_shared<TreeNode>(left.root_node, elem,
            right.root_node)) {}

    bool empty() const { return root_node == nullptr; }

    const T& root() const {
        assert(root_node != nullptr);
        return root_node->elem;
    }

    BinTree left() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->left;
        return result;
    }

    BinTree right() const {
        assert(root_node != nullptr);
        BinTree result;
        result.root_node = root_node->right;
        return result;
    }

    void display(std::ostream& out) const { display_node(root_node, out); }

private:
    // Las definiciones de TreeNode y NodePointer dependen recursivamente
    // la una de la otra. Por eso declaro 'struct TreeNode;' antes de NodePointer
    // para que el compilador sepa, cuando analice la definici�n de NodePointer,
    // que TreeNode va a ser definida m�s adelante.

    struct TreeNode;
    using NodePointer = std::shared_ptr<TreeNode>;

    struct TreeNode {
        TreeNode(const NodePointer& left, const T& elem, const NodePointer& right)
            : elem(elem), left(left), right(right) {}

        T elem;
        NodePointer left, right;
    };

    NodePointer root_node;

    static void display_node(const NodePointer& root, std::ostream& out) {
        if (root == nullptr) {
            out << ".";
        }
        else {
            out << "(";
            display_node(root->left, out);
            out << " " << root->elem << " ";
            display_node(root->right, out);
            out << ")";
        }
    }
};

template <typename T>
std::ostream& operator<<(std::ostream& out, const BinTree<T>& tree) {
    tree.display(out);
    return out;
}

template <typename T> BinTree<T> read_tree(std::istream& in) {
    char c;
    in >> c;
    if (c == '.') {
        return BinTree<T>();
    }
    else {
        assert(c == '(');
        BinTree<T> left = read_tree<T>(in);
        T elem;
        in >> elem;
        BinTree<T> right = read_tree<T>(in);
        in >> c;
        assert(c == ')');
        BinTree<T> result(left, elem, right);
        return result;
    }
}

using namespace std;


// Devuelve:
//  - Primera componente: n� de equipos de rescate necesarios
//  - Segunda componente: n�mero de excursionistas que se encuentran en la ruta con m�s excursionistas. Es c�mo si fuera el n�mero m�ximo de excursionistas que puede salvar un grupo de rescate.
pair<int, int> excursionistas(const BinTree<int>& t) {

    if (t.empty())
    {
        return{ 0,0 };
    }
    else
    {
        auto [rescate_izquierda, excursionistas_izquierda] = excursionistas(t.left());
        auto [rescate_derecha, excursionistas_derecha] = excursionistas(t.right());

        if (rescate_izquierda ==0 &&rescate_derecha==0)
        {
            //Si no necesita excursionista
            if (t.root()==0)
            {
                return{ 0,0 };
            }
            else if (t.root() != 0) {


                //Necesitaras un rescate para salvar a ese numero de excursionistas.
                return{ 1,t.root() };
            }
        }
        else
        {
            return{ rescate_izquierda + rescate_derecha,max(excursionistas_izquierda,excursionistas_derecha) + t.root() };
        }


    }
}


/*
COSTE Y RECURRENCIA:

Voy a definir la recurrencia sobre el n�mero de nodos que tiene nuestro �rbol binario. Destacar que solo tenemos
una funci�n donde calculamos todo. De otra forma, si lo hubieramos hecho con dos funciones distintas para calcular
en una el n�mero de excursionistas y en otra el n�mero de equipos de rescate, nos costar�a m�s. Voy a definir la
recurrencia sobre n siendo este el n�mero de nodos de mi �rbol binario. ni = nodos izquierda, nd = nodos derecha.

            {k0                 si n=0;
        T(n)
            {T(ni) + T(nd) +k1  si n>0;


        Por tanto, seg�n la recurrencia, el coste de nuestro algoritmo ser� Lineal en el n�mero de nodos O(n)<.



*/


void tratar_caso() {
    // Introduce aqu� el c�digo para tratar un caso de prueba.

    BinTree<int> t = read_tree<int>(cin);
    auto [num_equipos, max_rescate] = excursionistas(t);

    cout << num_equipos << " " << max_rescate << "\n";
}

int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    int numCasos;

    cin >> numCasos;

    for (int i = 0; i < numCasos; i++)
    {
        tratar_caso();
    }

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    // Descomentar si se trabaja en Windows
    // system("PAUSE");
#endif
    return 0;
}