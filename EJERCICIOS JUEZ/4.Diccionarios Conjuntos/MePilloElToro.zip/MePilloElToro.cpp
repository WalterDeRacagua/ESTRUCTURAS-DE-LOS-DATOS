// Me pill� el toro
// ----------------
// Estructuras de datos


// Utiliza las clases de la STL de C++ para este problema
// A�ade los #include que creas necesarios

#include <iostream>
#include <fstream>
#include <cassert>
#include <map>
#include <string>

using namespace std;


// 
// Implementa a continuaci�n la funci�n que trata un caso de prueba.
// Devuelve false si, en lugar de un caso de prueba, se encuentra la marca
// de fin de la entrada (0), o true en caso contrario.
//

bool tratar_caso() {
    
    int n = 0;

    cin >> n;

    if (n==0)
    {
        return false;
    }

    map<string, int> alumnos;
    string nombre;
    string correccion;

    cin.ignore();

    for (int i = 0; i < n; i++)
    {
        getline(cin, nombre);
        cin >> correccion;

        if (correccion =="INCORRECTO")
        {
            if (alumnos.count(nombre))
            {
                alumnos[nombre]--;
            }
            else
                alumnos[nombre] = -1;
        }
        else
        {
            alumnos[nombre]++;
        }

        if (alumnos[nombre]==0)
        {
            alumnos.erase(nombre);
        }

        cin.ignore();
    }

    for (auto a: alumnos)
    {
        cout << a.first << ", " << a.second << "\n";
    }

    cout << "---\n";

    return true;
}


int main() {

    // Si est�s ejecutando el programa en tu ordenador, las siguientes l�neas
    // redirigiran cualquier lectura de cin al fichero 'sample.in'. Esto es
    // �til para no tener que teclear los casos de prueba por teclado cada vez
    // que ejecutas el programa.
    //
    // Si prefieres teclear los casos de prueba por teclado en tu ordenador,
    // comenta las l�neas comprendidas entre los #ifndef y #endif
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
    // Llamamos tantas veces a `tratar_caso` como nos diga el n�mero.
    while (tratar_caso()) {}
    // Comenta esto tambi�n si has comentado lo anterior.
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}