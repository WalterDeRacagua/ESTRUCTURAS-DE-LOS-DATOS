// Elecciones Presidenciales
// -------------------------
// Estructuras de datos

// A�ade los #include que creas necesarios

#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <map>
#include <utility>
using namespace std;


class ConteoVotos {
public:
    void nuevo_estado(const string& nombre, int num_compromisarios) {

        if (this->estados.count(nombre))
        {
            throw domain_error("Estado ya existente");
        }

        this->estados[nombre] = num_compromisarios;
        
        
    }

    void sumar_votos(const string& estado, const string& partido, int num_votos) {//O(1)

        if (!this->estados.count(estado)) {
            throw domain_error("Estado no encontrado");
        }

        this->estados[estado].votos[partido] += num_votos; // O(1);

        if (this->estados[estado].ganador == " " ||
            this->estados[estado].votos[partido] > this->estados[estado].votos[this->estados[estado].ganador]) {

            // Restar compromisarios del antiguo ganador si lo hay
            if (this->estados[estado].ganador != " ") {
                this->partidos[this->estados[estado].ganador] -= this->estados[estado].num_compromisarios;
                if (this->partidos[this->estados[estado].ganador] == 0) {
                    this->partidos.erase(this->estados[estado].ganador);
                }
            }

            // Actualizar el ganador del estado
            this->estados[estado].ganador = partido;

            // Sumar compromisarios al nuevo ganador
            this->partidos[partido] += this->estados[estado].num_compromisarios;
        }
    }

    string ganador_en(const string& estado) const {

        if (!this->estados.count(estado))
        {
            throw domain_error("Estado no encontrado");
        }

        return this->estados.at(estado).ganador;
    }

    vector<pair<string, int>> resultados() const {

        vector<pair<string, int>> resultados;

        for (auto partidos: this->partidos)
        {
            resultados.push_back({ partidos.first,partidos.second });
        }

        return resultados;
    }

private:

    struct InfoEstado
    {
        unordered_map<string, int> votos;
        int num_compromisarios;
        string ganador;

        InfoEstado() : num_compromisarios(0), ganador(" ") {} // Constructor predeterminado
        InfoEstado(int num_compromisarios) : votos(), num_compromisarios(num_compromisarios), ganador(" ") {};
    };

    unordered_map<string, InfoEstado> estados;
    map <string, int> partidos;


};


bool tratar_caso() {
    string comando;
    cin >> comando;
    if (cin.eof()) return false;

    ConteoVotos cv;

    while (comando != "FIN") {
        try {
            if (comando == "nuevo_estado") {
                string estado;
                int num_compromisarios;
                cin >> estado >> num_compromisarios;
                cv.nuevo_estado(estado, num_compromisarios);
            }
            else if (comando == "sumar_votos") {
                string estado;
                string partido;
                int num_votos;
                cin >> estado >> partido >> num_votos;
                cv.sumar_votos(estado, partido, num_votos);
            }
            else if (comando == "ganador_en") {
                string estado;
                cin >> estado;
                string ganador = cv.ganador_en(estado);
                cout << "Ganador en " << estado << ": " << ganador << "\n";
            }
            else if (comando == "resultados") {
                for (const auto& [partido, num_comp] : cv.resultados()) {
                    cout << partido << " " << num_comp << "\n";
                }
            }
        }
        catch (std::exception& e) {
            cout << e.what() << "\n";
        }
        cin >> comando;
    }

    cout << "---\n";
    return true;
}

int main() {
#ifndef DOMJUDGE
    std::ifstream in("sample.in");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (tratar_caso()) {}

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    // Descomentar si se trabaja en Windows
    // system("PAUSE");
#endif
    return 0;
}
